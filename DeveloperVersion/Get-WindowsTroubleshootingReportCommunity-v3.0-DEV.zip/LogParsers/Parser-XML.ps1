# Parser-XML.ps1
# Parser for XML-based log files
# Handles: Generic XML logs, exported ETL→XML, evtx exports to XML
# Part of Get-WindowsTroubleshootingReportCommunity v3.0
#
# Strategy: Uses [xml] to parse the document, then walks Event nodes
# Supports both Windows Event XML exports and tracerpt ETL→XML output

function Convert-BinaryEventDataToString {
    # Best-effort decode of a <BinaryEventData> hex string from tracerpt XML.
    # Priority:
    #   1. 4-byte blob → LE DWORD decimal, or hex if it looks like an error/status code
    #   2. Any size → UTF-16LE decode, keep only if the result is mostly ASCII printable
    #   3. Fallback → "[BinaryData: N bytes]"
    param([string]$Hex)

    $Hex = $Hex.Trim()
    if(-not $Hex) { return '' }

    # Convert hex pairs to bytes
    $bytes = try {
        [byte[]]@(for ($i = 0; $i -lt $Hex.Length - 1; $i += 2) {
            [Convert]::ToByte($Hex.Substring($i, 2), 16)
        })
    } catch { return "[BinaryData: invalid hex]" }

    $byteCount = $bytes.Count
    if($byteCount -eq 0) { return '' }

    # 4-byte blob: most likely a numeric code (NTSTATUS, HRESULT, DWORD flags)
    if($byteCount -eq 4) {
        $dword = [BitConverter]::ToUInt32($bytes, 0)
        # Show as hex if high bit set (NTSTATUS / HRESULT error) or in well-known large-code ranges.
        # 2147483648 = 0x80000000; use decimal literal to avoid PowerShell Int32 sign-extension bug.
        if($dword -ge 2147483648 -or ($dword -ge 65536 -and $dword -le 268435455)) {
            return '0x{0:X8}' -f $dword
        }
        return $dword.ToString()
    }

    # Try UTF-16LE — common for ETW events that log file paths or string values.
    # Only accept if the decoded text is mostly ASCII printable (space–tilde range).
    # Using [char]::IsLetterOrDigit() is too broad — it accepts CJK/Korean/etc from random bytes.
    if($byteCount % 2 -eq 0) {
        $decoded = try { [System.Text.Encoding]::Unicode.GetString($bytes) } catch { $null }
        if($decoded -and $decoded.Length -gt 0) {
            $asciiPrintable = ($decoded.ToCharArray() | Where-Object { [int]$_ -ge 0x20 -and [int]$_ -le 0x7E }).Count
            if($asciiPrintable -ge 4 -and $asciiPrintable / $decoded.Length -ge 0.70) {
                # Strip control chars and null terminators, trim whitespace
                return ($decoded -replace '[\x00-\x1F\x7F]', '').Trim()
            }
        }
    }

    # Nothing readable — report size so user knows data exists
    return "[BinaryData: $byteCount bytes]"
}

function Test-XMLFormat {
    param([string[]]$Lines)
    foreach($line in $Lines) {
        $trimmed = $line.Trim()
        if($trimmed -eq '' -or $trimmed -match '^\s*$') { continue }
        if($trimmed -match '^<\?xml' -or $trimmed -match '^<Events' -or $trimmed -match '^<EventTrace') {
            return $true
        }
        return $false  # First non-empty line doesn't start with XML marker
    }
    return $false
}

function Get-XMLTimeRange {
    param(
        [Parameter(Mandatory=$true)] [string]$FilePath
    )

    $oldest = $null
    $newest = $null

    try {
        # Strip default namespace declarations so XPath works regardless of whether
        # tracerpt adds xmlns="..." to Event nodes (which would cause //Event to match nothing)
        $rawXml = (Get-Content -Path $FilePath -Raw -ErrorAction Stop) -replace 'xmlns="[^"]*"', ''
        [xml]$doc = $rawXml
    } catch {
        return @{ Oldest = $null; Newest = $null }
    }

    # Windows Event Log XML export format
    $events = $doc.SelectNodes('//Event/System/TimeCreated')
    if(-not $events -or $events.Count -eq 0) {
        # tracerpt ETL→XML format
        $events = $doc.SelectNodes('//Event')
    }

    if($events -and $events.Count -gt 0) {
        foreach($evt in $events) {
            $timeStr = $null
            if($evt.SystemTime) { $timeStr = $evt.SystemTime }
            elseif($evt.GetAttribute('SystemTime')) { $timeStr = $evt.GetAttribute('SystemTime') }
            elseif($evt.'#text') { $timeStr = $evt.'#text' }
            elseif($evt.ParentNode -and $evt.ParentNode.SelectSingleNode('.//TimeCreated')) {
                $tc = $evt.ParentNode.SelectSingleNode('.//TimeCreated')
                $timeStr = $tc.GetAttribute('SystemTime')
            }

            if($timeStr) {
                # tracerpt emits 9 fractional-second digits (e.g. .692688600).
                # [datetime]::Parse() only accepts up to 7 — truncate the excess digits
                # before parsing, otherwise every tracerpt timestamp throws and is silently skipped.
                $timeStr = $timeStr -replace '(\.\d{7})\d+', '$1'
                try {
                    $dt = [datetime]::Parse($timeStr)
                    if(-not $oldest -or $dt -lt $oldest) { $oldest = $dt }
                    if(-not $newest -or $dt -gt $newest) { $newest = $dt }
                } catch { }
            }
        }
    }

    return @{ Oldest = $oldest; Newest = $newest }
}

function Read-XMLLogEntries {
    <#
    .SYNOPSIS
        Parses XML-based log files (event log exports, tracerpt output)
    .DESCRIPTION
        Iterates Event nodes, extracts timestamps, provider, event ID, level and message.

        Two execution paths depending on file size:
          Small files (<= 5 MB)  — load with [xml] and walk SelectNodes('//Event').
          Large files  (> 5 MB)  — stream with XmlReader, parse one <Event> at a time.

        The streaming path exists because [xml] loads the entire file into memory.
        A 22 MB Wifi.etl tracerpt XML caused [xml] to fail silently (or OOM), returning
        zero entries. XmlReader processes <Event> elements one at a time with constant
        memory regardless of file size.

        Known tracerpt XML quirks handled here:
          1. xmlns="..." on <Event>  — XPath '//Event' returns nothing if a default
             namespace is present. Strip it with -replace before parsing.
          2. 9-digit fractional seconds — tracerpt emits SystemTime values like
             '2026-03-30T08:18:16.692688600+02:59'. [datetime]::Parse() only accepts
             up to 7 fractional digits. Truncate with -replace '(\\.[0-9]{7})[0-9]+','\$1'.
          3. Empty message strings — some ETL header/metadata events have no EventData
             and no RenderingInfo. Match-EventRulesForLogEntry requires [AllowEmptyString()]
             on its \$LogMessage param; without it, PowerShell throws a binding exception
             that is caught by the outer try/catch, silently aborting the stream loop.
    #>
    param(
        [Parameter(Mandatory=$true)] [string]$FilePath,
        [Parameter(Mandatory=$true)] $StartTimeObject,
        [Parameter(Mandatory=$true)] $EndTimeObject,
        [Parameter(Mandatory=$true)] [string]$LogFileName,
        [Parameter(Mandatory=$false)] [array]$KnownLogEventRuleObjects = @(),
        [Parameter(Mandatory=$false)] [bool]$AllEvents = $false
    )

    # Use List[object] instead of a PowerShell array (@()) so that .Add() is O(1).
    # Array += copies the entire array on every append — O(n^2) total for n events.
    # A 22 MB tracerpt XML contains ~20 000 events; += made that loop take many minutes.
    $entries = [System.Collections.Generic.List[object]]::new()

    # Threshold: tracerpt XML for a typical ETL session is 1-25 MB. Files up to 5 MB
    # are small enough to load with [xml] (simpler code, faster XPath). Larger files
    # are streamed one <Event> at a time to keep memory usage flat.
    $fileSizeBytes = (Get-Item -LiteralPath $FilePath -ErrorAction SilentlyContinue).Length
    $useStreaming = ($fileSizeBytes -gt 5MB)

    if($useStreaming) {
        # --- Streaming path: one <Event> at a time via XmlReader ---
        # DtdProcessing.Ignore prevents an exception on the <!DOCTYPE> declaration that
        # some tracerpt versions include in their XML preamble.
        $reader = $null
        $eventNumber = 0
        try {
            $settings = [System.Xml.XmlReaderSettings]::new()
            $settings.DtdProcessing = [System.Xml.DtdProcessing]::Ignore
            $reader = [System.Xml.XmlReader]::Create($FilePath, $settings)

            while($reader.Read()) {
                if($reader.NodeType -ne [System.Xml.XmlNodeType]::Element) { continue }
                if($reader.LocalName -ne 'Event') { continue }

                # ReadOuterXml() returns the full element as a string AND advances the
                # reader past it, so the outer while() loop continues with the next sibling.
                $outerXml = $reader.ReadOuterXml()
                # Strip default namespace — tracerpt adds xmlns="http://schemas.microsoft.com/..."
                # to every <Event> node. Without stripping it, XPath selectors like
                # SelectSingleNode('System') return nothing (namespace mismatch).
                $outerXml = $outerXml -replace 'xmlns="[^"]*"', ''

                $miniDoc = $null
                try { [xml]$miniDoc = $outerXml } catch { continue }
                $eventNode = $miniDoc.DocumentElement
                if(-not $eventNode) { continue }
                $eventNumber++

                $dateObj = $null; $provider = ''; $eventId = ''; $level = 'Information'; $message = ''

                $system = $eventNode.SelectSingleNode('System')
                if($system) {
                    $tc = $system.SelectSingleNode('TimeCreated')
                    if($tc) {
                        $sysTime = $tc.GetAttribute('SystemTime')
                        if($sysTime) {
                            # tracerpt emits 9 fractional-second digits (e.g. .692688600).
                            # [datetime]::Parse() only accepts up to 7 — truncate the excess.
                            $sysTime = $sysTime -replace '(\.\d{7})\d+', '$1'
                            try { $dateObj = [datetime]::Parse($sysTime) } catch { }
                        }
                    }

                    $provNode = $system.SelectSingleNode('Provider')
                    if($provNode) { $provider = $provNode.GetAttribute('Name') }

                    $idNode = $system.SelectSingleNode('EventID')
                    if($idNode) { $eventId = $idNode.InnerText }

                    $levelNode = $system.SelectSingleNode('Level')
                    if($levelNode) {
                        switch($levelNode.InnerText) {
                            '1' { $level = 'Critical' } '2' { $level = 'Error' } '3' { $level = 'Warning' }
                            '4' { $level = 'Information' } '5' { $level = 'Verbose' } default { $level = $levelNode.InnerText }
                        }
                    }

                    $renderInfo = $eventNode.SelectSingleNode('RenderingInfo/Message')
                    $eventData  = $eventNode.SelectSingleNode('EventData')
                    $binaryData = $eventNode.SelectSingleNode('BinaryEventData')
                    if($renderInfo -and $renderInfo.InnerText.Trim()) {
                        $message = $renderInfo.InnerText
                    } elseif($eventData) {
                        $dataParts = @()
                        foreach($d in $eventData.SelectNodes('Data')) {
                            $n = $d.GetAttribute('Name')
                            if($n) { $dataParts += "$n=$($d.InnerText)" } else { $dataParts += $d.InnerText }
                        }
                        $message = $dataParts -join '; '
                    } elseif($binaryData -and $binaryData.InnerText.Trim()) {
                        $message = Convert-BinaryEventDataToString -Hex $binaryData.InnerText.Trim()
                    }
                } else {
                    # Flat-attribute format (older tracerpt or custom ETL exporters)
                    $sysTime = $eventNode.GetAttribute('SystemTime')
                    if(-not $sysTime) { $sysTime = $eventNode.GetAttribute('Timestamp') }
                    if($sysTime) { $sysTime = $sysTime -replace '(\.\d{7})\d+', '$1'; try { $dateObj = [datetime]::Parse($sysTime) } catch { } }
                    $provider = $eventNode.GetAttribute('Provider')
                    if(-not $provider) { $provider = $eventNode.GetAttribute('ProviderName') }
                    $eventId = $eventNode.GetAttribute('Id')
                    $message = $eventNode.InnerText
                }

                if(-not $dateObj) { continue }
                if($dateObj -lt $StartTimeObject -or $dateObj -gt $EndTimeObject) { continue }

                $color = $null
                switch($level) { 'Critical' { $color = 'Red' } 'Error' { $color = 'Red' } 'Warning' { $color = 'Yellow' } }

                $dateTimeline = Format-DateTimeForTimeline -Year $dateObj.Year.ToString() -Month $dateObj.Month.ToString() -Day $dateObj.Day.ToString() -Hour $dateObj.Hour.ToString() -Minute $dateObj.Minute.ToString() -Second $dateObj.Second.ToString()

                $entry = @{ DateTimeObject = $dateObj; Date = $dateTimeline; LogName = $LogFileName; ProviderName = $provider; Id = $eventId; LevelDisplayName = $level; Message = $message; Color = $color; EventNumber = $eventNumber; MessageToolTip = $null; KnownCategoryName = $null }

                $ruleMatch = Match-EventRulesForLogEntry -LogMessage $message -KnownLogEventRuleObjects $KnownLogEventRuleObjects
                if($ruleMatch) {
                    $entry.Color = $ruleMatch.Color; $entry.MessageToolTip = $ruleMatch.MessageToolTip; $entry.KnownCategoryName = $ruleMatch.CategoryName
                    $entries.Add($entry)
                } elseif($AllEvents -or $color) {
                    $entries.Add($entry)
                }
            }
        } catch {
            Write-Warning "Failed to stream XML file: $FilePath - $_"
        } finally {
            if($reader) { $reader.Dispose() }
        }
        return $entries
    }

    # --- Non-streaming path: load full [xml] document ---
    try {
        # Strip default namespace declarations before handing the XML to [xml].
        # tracerpt adds xmlns="http://schemas.microsoft.com/win/2004/08/events/event" to
        # every <Event> node. With this namespace present, XPath '//Event' matches nothing
        # because .NET's XmlDocument treats unqualified names as belonging to no namespace,
        # while the nodes belong to the declared one. Stripping it makes the XPath work.
        $rawXml = (Get-Content -Path $FilePath -Raw -ErrorAction Stop) -replace 'xmlns="[^"]*"', ''
        [xml]$doc = $rawXml
    } catch {
        Write-Warning "Failed to parse XML file: $FilePath - $_"
        return $entries
    }

    $eventNodes = $doc.SelectNodes('//Event')
    if(-not $eventNodes -or $eventNodes.Count -eq 0) { return $entries }

    $eventNumber = 0
    foreach($eventNode in $eventNodes) {
        $eventNumber++

        $dateObj = $null; $provider = ''; $eventId = ''; $level = 'Information'; $message = ''

        $system = $eventNode.SelectSingleNode('System')
        if($system) {
            $tc = $system.SelectSingleNode('TimeCreated')
            if($tc) {
                $sysTime = $tc.GetAttribute('SystemTime')
                if($sysTime) {
                    # tracerpt emits 9 fractional-second digits; [datetime]::Parse() max is 7.
                    $sysTime = $sysTime -replace '(\.\d{7})\d+', '$1'
                    try { $dateObj = [datetime]::Parse($sysTime) } catch { }
                }
            }

            $provNode = $system.SelectSingleNode('Provider')
            if($provNode) { $provider = $provNode.GetAttribute('Name') }

            $idNode = $system.SelectSingleNode('EventID')
            if($idNode) { $eventId = $idNode.InnerText }

            $levelNode = $system.SelectSingleNode('Level')
            if($levelNode) {
                switch($levelNode.InnerText) {
                    '1' { $level = 'Critical' }
                    '2' { $level = 'Error' }
                    '3' { $level = 'Warning' }
                    '4' { $level = 'Information' }
                    '5' { $level = 'Verbose' }
                    default { $level = $levelNode.InnerText }
                }
            }

            # Message priority: RenderingInfo/Message > EventData/Data > BinaryEventData
            $renderInfo = $eventNode.SelectSingleNode('RenderingInfo/Message')
            $eventData  = $eventNode.SelectSingleNode('EventData')
            $binaryData = $eventNode.SelectSingleNode('BinaryEventData')
            if($renderInfo -and $renderInfo.InnerText.Trim()) {
                $message = $renderInfo.InnerText
            } elseif($eventData) {
                $dataNodes = $eventData.SelectNodes('Data')
                $dataParts = @()
                foreach($d in $dataNodes) {
                    $name = $d.GetAttribute('Name')
                    $val  = $d.InnerText
                    if($name) { $dataParts += "$name=$val" } else { $dataParts += $val }
                }
                $message = $dataParts -join '; '
            } elseif($binaryData -and $binaryData.InnerText.Trim()) {
                $message = Convert-BinaryEventDataToString -Hex $binaryData.InnerText.Trim()
            }
        } else {
            # Flat-attribute format (older tracerpt or custom ETL exporters)
            $sysTime = $eventNode.GetAttribute('SystemTime')
            if(-not $sysTime) { $sysTime = $eventNode.GetAttribute('Timestamp') }
            if($sysTime) {
                # Same 9-digit fractional-seconds truncation as the streaming path.
                $sysTime = $sysTime -replace '(\.\d{7})\d+', '$1'
                try { $dateObj = [datetime]::Parse($sysTime) } catch { }
            }

            $provider = $eventNode.GetAttribute('Provider')
            if(-not $provider) { $provider = $eventNode.GetAttribute('ProviderName') }
            $eventId = $eventNode.GetAttribute('Id')
            $message = $eventNode.InnerText
        }

        if(-not $dateObj) { continue }
        if($dateObj -lt $StartTimeObject -or $dateObj -gt $EndTimeObject) { continue }

        $color = $null
        switch($level) {
            'Critical' { $color = 'Red' }
            'Error'    { $color = 'Red' }
            'Warning'  { $color = 'Yellow' }
        }

        $Year = $dateObj.Year.ToString(); $Month = $dateObj.Month.ToString(); $Day = $dateObj.Day.ToString()
        $HourStr = $dateObj.Hour.ToString(); $MinuteStr = $dateObj.Minute.ToString(); $SecondStr = $dateObj.Second.ToString()
        $dateTimeline = Format-DateTimeForTimeline -Year $Year -Month $Month -Day $Day -Hour $HourStr -Minute $MinuteStr -Second $SecondStr

        $entry = @{
            DateTimeObject   = $dateObj
            Date             = $dateTimeline
            LogName          = $LogFileName
            ProviderName     = $provider
            Id               = $eventId
            LevelDisplayName = $level
            Message          = $message
            Color            = $color
            EventNumber      = $eventNumber
            MessageToolTip   = $null
            KnownCategoryName = $null
        }

        $ruleMatch = Match-EventRulesForLogEntry -LogMessage $message -KnownLogEventRuleObjects $KnownLogEventRuleObjects
        if($ruleMatch) {
            $entry.Color = $ruleMatch.Color
            $entry.MessageToolTip = $ruleMatch.MessageToolTip
            $entry.KnownCategoryName = $ruleMatch.CategoryName
            $entries.Add($entry)
        } elseif($AllEvents -or $color) {
            $entries.Add($entry)
        }
    }

    return $entries
}

