# Parser-CBS.ps1
# Parser for CBS/Panther format log files
# Handles: CBS.log, dism.log, DPX, setupact.log, setuperr.log, WinSetup/MoSetup entries
# Part of Get-WindowsTroubleshootingReportCommunity v3.0
#
# Line Format: YYYY-MM-DD HH:MM:SS, Level Component Message
# Regex: ^(\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2}),\s+(Info|Error|Warning|Perf)\s+(?:\[0x[0-9a-fA-F]+\]\s+)?(\S+)\s+(.+)$

$Script:CBSLineRegex = '^\s*(\d{4})-(\d{2})-(\d{2})\s+(\d{2}):(\d{2}):(\d{2}),\s+(Info|Error|Warning|Perf)\s+(?:\[0x[0-9a-fA-F]+\]\s+)?(\S+)\s+(.+)$'

function Test-CBSFormat {
    param([string[]]$Lines)
    foreach($line in $Lines) {
        if($line -match $Script:CBSLineRegex) { return $true }
    }
    return $false
}

function Get-CBSTimeRange {
    param(
        [Parameter(Mandatory=$true)] [AllowEmptyString()] [string[]]$LogFileLines
    )

    $oldest = $null
    $newest = $null

    # Find oldest from start
    foreach($line in $LogFileLines) {
        if($line -match $Script:CBSLineRegex) {
            try {
                $oldest = Get-Date -Year $Matches[1] -Month $Matches[2] -Day $Matches[3] -Hour $Matches[4] -Minute $Matches[5] -Second $Matches[6] -ErrorAction Stop
                break
            } catch { continue }
        }
    }

    # Find newest from end
    for($i = $LogFileLines.Count - 1; $i -ge 0; $i--) {
        if($LogFileLines[$i] -match $Script:CBSLineRegex) {
            try {
                $newest = Get-Date -Year $Matches[1] -Month $Matches[2] -Day $Matches[3] -Hour $Matches[4] -Minute $Matches[5] -Second $Matches[6] -ErrorAction Stop
                break
            } catch { continue }
        }
    }

    return @{ Oldest = $oldest; Newest = $newest }
}

function Read-CBSLogEntries {
    <#
    .SYNOPSIS
        Parses CBS/Panther format log files line by line
    .DESCRIPTION
        Handles multi-line entries (lines without timestamp are continuations).
        Maps Error → Red, Warning → Yellow.
    #>
    param(
        [Parameter(Mandatory=$true)] [AllowEmptyString()] [string[]]$LogFileLines,
        [Parameter(Mandatory=$true)] $StartTimeObject,
        [Parameter(Mandatory=$true)] $EndTimeObject,
        [Parameter(Mandatory=$true)] [string]$LogFileName,
        [Parameter(Mandatory=$false)] [array]$KnownLogEventRuleObjects = @(),
        [Parameter(Mandatory=$false)] [bool]$AllEvents = $false
    )

    $entries = @()
    $lineNumber = 0
    $currentEntry = $null
    $consecutiveFailures = 0

    foreach($line in $LogFileLines) {
        $lineNumber++
        $line = $line -replace "^\uFEFF", ""

        if($consecutiveFailures -ge 20) {
            Write-Verbose "CBS parser: Too many consecutive parse failures, stopping"
            break
        }

        if($line -match $Script:CBSLineRegex) {
            $consecutiveFailures = 0

            # Save previous entry if it exists and is within time range
            if($currentEntry) {
                $entries += $currentEntry
            }

            $Year = $Matches[1]; $Month = $Matches[2]; $Day = $Matches[3]
            $Hour = $Matches[4]; $Minute = $Matches[5]; $Second = $Matches[6]
            $Level = $Matches[7]; $Component = $Matches[8]; $Message = $Matches[9]

            try {
                $dateObj = Get-Date -Year $Year -Month $Month -Day $Day -Hour $Hour -Minute $Minute -Second $Second -ErrorAction Stop
            } catch {
                continue
            }

            if($dateObj -lt $StartTimeObject -or $dateObj -gt $EndTimeObject) {
                $currentEntry = $null
                continue
            }

            # Map level to display name and color
            $color = $null
            $levelDisplay = $Level
            switch($Level) {
                'Error'   { $color = 'Red'; $levelDisplay = 'Error' }
                'Warning' { $color = 'Yellow'; $levelDisplay = 'Warning' }
                'Info'    { $levelDisplay = 'Information' }
                'Perf'    { $levelDisplay = 'Information' }
            }

            $dateStr = Format-DateTimeForTimeline -Year $Year -Month $Month -Day $Day -Hour $Hour -Minute $Minute -Second $Second

            $currentEntry = @{
                DateTimeObject = $dateObj
                Date = $dateStr
                LogName = $LogFileName
                ProviderName = $Component
                Id = ''
                LevelDisplayName = $levelDisplay
                Message = $Message
                Color = $color
                EventNumber = $lineNumber
                MessageToolTip = $null
                KnownCategoryName = $null
            }

            # Check EventRules
            $ruleMatch = Match-EventRulesForLogEntry -LogMessage $Message -KnownLogEventRuleObjects $KnownLogEventRuleObjects
            if($ruleMatch) {
                $currentEntry.Color = $ruleMatch.Color
                $currentEntry.MessageToolTip = $ruleMatch.MessageToolTip
                $currentEntry.KnownCategoryName = $ruleMatch.CategoryName
            } elseif(-not $AllEvents) {
                # If not AllEvents and no rule match, skip (only record known events)
                $currentEntry = $null
                continue
            }

        } elseif($currentEntry -and $line.Trim().Length -gt 0) {
            # Multi-line continuation - append to current entry
            $currentEntry.Message = "$($currentEntry.Message)`n$line"
        } else {
            $consecutiveFailures++
        }
    }

    # Don't forget the last entry
    if($currentEntry) {
        $entries += $currentEntry
    }

    return $entries
}
