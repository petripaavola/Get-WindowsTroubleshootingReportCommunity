# Parser-WindowsUpdate.ps1
# Parser for Windows Update logs (WindowsUpdate.log format)
# Handles: WindowsUpdate.log (legacy pre-Win10 format with 7-digit timestamps)
# Part of Get-WindowsTroubleshootingReportCommunity v3.0
#
# Format: YYYY-MM-DD HH:MM:SS:mmm PID TID Component Message
# Some lines have YYYY/MM/DD instead of YYYY-MM-DD

$Script:WindowsUpdateLineRegex = '^\s*(\d{4})[-/](\d{2})[-/](\d{2})\s+(\d{2}):(\d{2}):(\d{2})[.:](\d{3,7})\s+(\d+)\s+(\d+)\s+(\S+)\s+(.+)$'

function Test-WindowsUpdateFormat {
    param([string[]]$Lines)
    $matchCount = 0
    $testLines = if($Lines.Count -gt 30) { $Lines[0..29] } else { $Lines }
    foreach($line in $testLines) {
        if($line -match $Script:WindowsUpdateLineRegex) {
            $matchCount++
            if($matchCount -ge 3) { return $true }
        }
    }
    return $false
}

function Get-WindowsUpdateTimeRange {
    param(
        [Parameter(Mandatory=$true)] [AllowEmptyString()] [string[]]$LogFileLines
    )

    $oldest = $null
    $newest = $null

    # Find first matching line from head
    foreach($line in $LogFileLines) {
        if($line -match $Script:WindowsUpdateLineRegex) {
            try {
                $ms = [int]($Matches[7].Substring(0, [Math]::Min(3, $Matches[7].Length)))
                $oldest = Get-Date -Year $Matches[1] -Month $Matches[2] -Day $Matches[3] -Hour $Matches[4] -Minute $Matches[5] -Second $Matches[6] -Millisecond $ms -ErrorAction Stop
                break
            } catch { continue }
        }
    }

    # Find last matching line from tail
    for($i = $LogFileLines.Count - 1; $i -ge 0; $i--) {
        if($LogFileLines[$i] -match $Script:WindowsUpdateLineRegex) {
            try {
                $ms = [int]($Matches[7].Substring(0, [Math]::Min(3, $Matches[7].Length)))
                $newest = Get-Date -Year $Matches[1] -Month $Matches[2] -Day $Matches[3] -Hour $Matches[4] -Minute $Matches[5] -Second $Matches[6] -Millisecond $ms -ErrorAction Stop
                break
            } catch { continue }
        }
    }

    return @{ Oldest = $oldest; Newest = $newest }
}

function Read-WindowsUpdateLogEntries {
    <#
    .SYNOPSIS
        Parses legacy WindowsUpdate.log files
    .DESCRIPTION
        Extracts structured timestamps, PIDs, threading, component names.
        Flags lines containing FATAL, ERROR as Red; WARNING as Yellow.
    #>
    param(
        [Parameter(Mandatory=$true)] [AllowEmptyString()] [string[]]$LogFileLines,
        [Parameter(Mandatory=$true)] $StartTimeObject,
        [Parameter(Mandatory=$true)] $EndTimeObject,
        [Parameter(Mandatory=$true)] [string]$LogFileName,
        [Parameter(Mandatory=$false)] [array]$KnownLogEventRuleObjects = @(),
        [Parameter(Mandatory=$false)] [bool]$AllEvents = $false
    )

    $entries = @()
    $lineNumber = 0

    foreach($line in $LogFileLines) {
        $lineNumber++
        $line = $line -replace "^\uFEFF", ""

        if($line -notmatch $Script:WindowsUpdateLineRegex) { continue }

        $Year = $Matches[1]; $Month = $Matches[2]; $Day = $Matches[3]
        $Hour = $Matches[4]; $Minute = $Matches[5]; $Second = $Matches[6]; $Millisecond = $Matches[7].Substring(0, [Math]::Min(3, $Matches[7].Length))
        $PID_val = $Matches[8]; $TID_val = $Matches[9]
        $component = $Matches[10]
        $message = $Matches[11]

        try {
            $dateObj = Get-Date -Year $Year -Month $Month -Day $Day -Hour $Hour -Minute $Minute -Second $Second -Millisecond ([int]$Millisecond) -ErrorAction Stop
        } catch { continue }

        if($dateObj -lt $StartTimeObject -or $dateObj -gt $EndTimeObject) { continue }

        $color = $null
        $levelDisplay = 'Information'

        # Auto-classify by message content
        if($message -match '\b(FATAL|FAIL)\b' -or $message -match '\bERROR\b' -or $message -match '\bHRESULT\s*=\s*0x8') {
            $color = 'Red'
            $levelDisplay = 'Error'
        } elseif($message -match '\bWARNING\b') {
            $color = 'Yellow'
            $levelDisplay = 'Warning'
        }

        $dateTimeline = Format-DateTimeForTimeline -Year $Year -Month $Month -Day $Day -Hour $Hour -Minute $Minute -Second $Second

        $entry = @{
            DateTimeObject = $dateObj
            Date = $dateTimeline
            LogName = $LogFileName
            ProviderName = $component
            Id = "$PID_val`:$TID_val"
            LevelDisplayName = $levelDisplay
            Message = $message
            Color = $color
            EventNumber = $lineNumber
            MessageToolTip = $null
            KnownCategoryName = $null
        }

        $ruleMatch = Match-EventRulesForLogEntry -LogMessage $message -KnownLogEventRuleObjects $KnownLogEventRuleObjects
        if($ruleMatch) {
            $entry.Color = $ruleMatch.Color
            $entry.MessageToolTip = $ruleMatch.MessageToolTip
            $entry.KnownCategoryName = $ruleMatch.CategoryName
            $entries += $entry
        } elseif($AllEvents -or $color) {
            $entries += $entry
        }
    }

    return $entries
}
