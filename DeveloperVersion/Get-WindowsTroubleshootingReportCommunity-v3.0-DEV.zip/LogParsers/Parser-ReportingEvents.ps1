# Parser-ReportingEvents.ps1
# Parser for Windows Update ReportingEvents.log
# Handles: ReportingEvents.log (tab-delimited with GUIDs)
# Part of Get-WindowsTroubleshootingReportCommunity v3.0
#
# Format: {GUID}\tYYYY-MM-DD HH:MM:SS:mmm(+offset)\tAgent\t...\tHR=0x...\tMessage
# Tab-delimited fields, first field is a GUID identifying the update

$Script:ReportingEventsLineRegex = '^\{([0-9A-Fa-f\-]+)\}\t(\d{4})-(\d{2})-(\d{2})\s+(\d{2}):(\d{2}):(\d{2}):(\d{3})([+-]\d{4})?\t(.+)$'

function Test-ReportingEventsFormat {
    param([string[]]$Lines)
    foreach($line in $Lines) {
        if($line -match '^\{[0-9A-Fa-f\-]+\}\t\d{4}-\d{2}-\d{2}') { return $true }
    }
    return $false
}

function Get-ReportingEventsTimeRange {
    param(
        [Parameter(Mandatory=$true)] [AllowEmptyString()] [string[]]$LogFileLines
    )

    $oldest = $null
    $newest = $null

    foreach($line in $LogFileLines) {
        if($line -match $Script:ReportingEventsLineRegex) {
            try {
                $dateObj = Get-Date -Year $Matches[2] -Month $Matches[3] -Day $Matches[4] -Hour $Matches[5] -Minute $Matches[6] -Second $Matches[7] -Millisecond $Matches[8] -ErrorAction Stop
                $oldest = $dateObj
                break
            } catch { continue }
        }
    }

    for($i = $LogFileLines.Count - 1; $i -ge 0; $i--) {
        if($LogFileLines[$i] -match $Script:ReportingEventsLineRegex) {
            try {
                $newest = Get-Date -Year $Matches[2] -Month $Matches[3] -Day $Matches[4] -Hour $Matches[5] -Minute $Matches[6] -Second $Matches[7] -Millisecond $Matches[8] -ErrorAction Stop
                break
            } catch { continue }
        }
    }

    return @{ Oldest = $oldest; Newest = $newest }
}

function Read-ReportingEventsLogEntries {
    <#
    .SYNOPSIS
        Parses ReportingEvents.log tab-delimited update event log
    .DESCRIPTION
        Splits on tabs, extracts GUID, timestamp, fields.
        Flags non-zero HRESULT as Error (Red).
    #>
    param(
        [Parameter(Mandatory=$true)] [AllowEmptyString()] [string[]]$LogFileLines,
        [Parameter(Mandatory=$true)] $StartTimeObject,
        [Parameter(Mandatory=$true)] $EndTimeObject,
        [Parameter(Mandatory=$true)] [string]$LogFileName,
        [Parameter(Mandatory=$false)] [array]$KnownLogEventRuleObjects = @(),
        [Parameter(Mandatory=$false)] [bool]$AllEvents = $false
    )

    $entries = @()
    $lineNumber = 0

    foreach($line in $LogFileLines) {
        $lineNumber++
        $line = $line -replace "^\uFEFF", ""

        if([string]::IsNullOrWhiteSpace($line)) { continue }

        # Split on tabs
        $fields = $line.Split("`t")
        if($fields.Count -lt 4) { continue }

        # First field should be GUID
        if($fields[0] -notmatch '^\{[0-9A-Fa-f\-]+\}$') { continue }

        $updateGUID = $fields[0]

        # Second field: timestamp
        if($fields[1] -notmatch '^(\d{4})-(\d{2})-(\d{2})\s+(\d{2}):(\d{2}):(\d{2}):(\d{3})') { continue }

        $Year = $Matches[1]; $Month = $Matches[2]; $Day = $Matches[3]
        $Hour = $Matches[4]; $Minute = $Matches[5]; $Second = $Matches[6]; $Millisecond = $Matches[7]

        try {
            $dateObj = Get-Date -Year $Year -Month $Month -Day $Day -Hour $Hour -Minute $Minute -Second $Second -Millisecond $Millisecond -ErrorAction Stop
        } catch { continue }

        if($dateObj -lt $StartTimeObject -or $dateObj -gt $EndTimeObject) { continue }

        # Remaining fields form the message
        $component = if($fields.Count -ge 3) { $fields[2] } else { 'WU' }
        $message = ($fields[2..($fields.Count-1)] -join ' | ')

        $color = $null
        $levelDisplay = 'Information'

        # Detect HRESULT failures
        if($message -match 'HR\s*=\s*0x[89A-Fa-f]' -or $message -match '\bFAIL' -or $message -match '\bERROR\b') {
            $color = 'Red'
            $levelDisplay = 'Error'
        } elseif($message -match '\bWARNING\b') {
            $color = 'Yellow'
            $levelDisplay = 'Warning'
        } elseif($message -match 'HR\s*=\s*0x0+\b' -or $message -match '\bSUCCESS') {
            $color = 'LightGreen'
            $levelDisplay = 'Information'
        }

        $dateTimeline = Format-DateTimeForTimeline -Year $Year -Month $Month -Day $Day -Hour $Hour -Minute $Minute -Second $Second

        $entry = @{
            DateTimeObject = $dateObj
            Date = $dateTimeline
            LogName = $LogFileName
            ProviderName = $component
            Id = $updateGUID
            LevelDisplayName = $levelDisplay
            Message = $message
            Color = $color
            EventNumber = $lineNumber
            MessageToolTip = $null
            KnownCategoryName = $null
        }

        $ruleMatch = Match-EventRulesForLogEntry -LogMessage $message -KnownLogEventRuleObjects $KnownLogEventRuleObjects
        if($ruleMatch) {
            $entry.Color = $ruleMatch.Color
            $entry.MessageToolTip = $ruleMatch.MessageToolTip
            $entry.KnownCategoryName = $ruleMatch.CategoryName
            $entries += $entry
        } elseif($AllEvents -or $color) {
            $entries += $entry
        }
    }

    return $entries
}
