# Parser-IntuneInventoryHarvester.ps1
# Parser for Intune Custom Inventory Harvester log files (both USA and Non-USA date formats)
# Part of Get-WindowsTroubleshootingReportCommunity v3.0
#
# Non-USA Format: DD.MM.YYYY HH.MM.SS [Level] Message
# Example: 19.12.2024 16.55.24 [Information] UploadData complete.
#
# USA Format: MM/DD/YYYY HH:MM:SS AM/PM [Level] Message
# Example: 12/19/2024 6:37:51 PM [Information] Next collection occurs at 12/19/2024 10:37:51 PM

$Script:IntuneHarvesterNonUSARegex = '^(\d{1,2})[.](\d{1,2})[.](\d{4})\s+(\d{1,2})[.](\d{1,2})[.](\d{1,2})\s+\[(\w+)\]\s+(.*)$'
$Script:IntuneHarvesterUSARegex = '^(\d{1,2})/(\d{1,2})/(\d{4})\s+(\d{1,2}):(\d{1,2}):(\d{1,2})\s+(AM|PM)\s+\[(\w+)\]\s+(.*)$'

########################################################################
# Non-USA variant: DD.MM.YYYY HH.MM.SS [Level] Message
########################################################################

function Test-IntuneInventoryHarvesterNonUSAFormat {
    param([string[]]$Lines)
    foreach($line in $Lines) {
        if($line -match $Script:IntuneHarvesterNonUSARegex) { return $true }
    }
    return $false
}

function Get-IntuneInventoryHarvesterNonUSATimeRange {
    param(
        [Parameter(Mandatory=$true)] [AllowEmptyString()] [string[]]$LogFileLines
    )

    $oldest = $null
    $newest = $null

    # Find oldest from start
    foreach($line in $LogFileLines) {
        if($line -match $Script:IntuneHarvesterNonUSARegex) {
            try {
                $oldest = Get-Date -Year $Matches[3] -Month $Matches[2] -Day $Matches[1] -Hour $Matches[4] -Minute $Matches[5] -Second $Matches[6] -ErrorAction Stop
                break
            } catch { continue }
        }
    }

    # Find newest from end
    for($i = $LogFileLines.Count - 1; $i -ge 0; $i--) {
        if($LogFileLines[$i] -match $Script:IntuneHarvesterNonUSARegex) {
            try {
                $newest = Get-Date -Year $Matches[3] -Month $Matches[2] -Day $Matches[1] -Hour $Matches[4] -Minute $Matches[5] -Second $Matches[6] -ErrorAction Stop
                break
            } catch { continue }
        }
    }

    return @{ Oldest = $oldest; Newest = $newest }
}

function Read-IntuneInventoryHarvesterNonUSALogEntries {
    param(
        [Parameter(Mandatory=$true)] [AllowEmptyString()] [string[]]$LogFileLines,
        [Parameter(Mandatory=$true)] $StartTimeObject,
        [Parameter(Mandatory=$true)] $EndTimeObject,
        [Parameter(Mandatory=$true)] [string]$LogFileName,
        [Parameter(Mandatory=$false)] [AllowEmptyCollection()] [array]$KnownLogEventRuleObjects = @(),
        [Parameter(Mandatory=$false)] [bool]$AllEvents = $false
    )

    $entries = @()
    $lineNumber = 0
    $consecutiveFailures = 0

    foreach($line in $LogFileLines) {
        $lineNumber++

        if($consecutiveFailures -ge 20) {
            Write-Verbose "IntuneInventoryHarvesterNonUSA parser: Too many consecutive parse failures, stopping"
            break
        }

        if($line -match $Script:IntuneHarvesterNonUSARegex) {
            $consecutiveFailures = 0

            $Day = $Matches[1]; $Month = $Matches[2]; $Year = $Matches[3]
            $Hour = $Matches[4]; $Minute = $Matches[5]; $Second = $Matches[6]
            $LevelDisplayName = $Matches[7]
            $LogMessage = $Matches[8].Trim()
            $Component = 'InventoryHarvester'

            try {
                $dateObj = Get-Date -Year $Year -Month $Month -Day $Day -Hour $Hour -Minute $Minute -Second $Second -ErrorAction Stop
            } catch { continue }

            if($dateObj -lt $StartTimeObject -or $dateObj -gt $EndTimeObject) { continue }

            $dateStr = Format-DateTimeForTimeline -Year $Year -Month $Month -Day $Day -Hour $Hour -Minute $Minute -Second $Second

            # Check event rules
            $ruleMatch = Match-EventRulesForLogEntry -LogMessage $LogMessage -KnownLogEventRuleObjects $KnownLogEventRuleObjects

            if($ruleMatch) {
                $entries += @{
                    DateTimeObject = $dateObj
                    Date = $dateStr
                    LogName = $LogFileName
                    ProviderName = $Component
                    Id = ''
                    LevelDisplayName = $LevelDisplayName
                    Message = $LogMessage
                    EventNumber = $lineNumber
                    Color = $ruleMatch.Color
                    MessageToolTip = $ruleMatch.MessageToolTip
                    KnownCategoryName = $ruleMatch.CategoryName
                }
            } elseif($AllEvents) {
                $entries += @{
                    DateTimeObject = $dateObj
                    Date = $dateStr
                    LogName = $LogFileName
                    ProviderName = $Component
                    Id = ''
                    LevelDisplayName = $LevelDisplayName
                    Message = $LogMessage
                    EventNumber = $lineNumber
                    Color = $null
                    MessageToolTip = $null
                    KnownCategoryName = $null
                }
            }
        } else {
            if($line.Trim().Length -gt 0) {
                $consecutiveFailures++
            }
        }
    }

    return $entries
}

########################################################################
# USA variant: MM/DD/YYYY HH:MM:SS AM/PM [Level] Message
########################################################################

function Test-IntuneInventoryHarvesterUSAFormat {
    param([string[]]$Lines)
    foreach($line in $Lines) {
        if($line -match $Script:IntuneHarvesterUSARegex) { return $true }
    }
    return $false
}

function Get-IntuneInventoryHarvesterUSATimeRange {
    param(
        [Parameter(Mandatory=$true)] [AllowEmptyString()] [string[]]$LogFileLines
    )

    $oldest = $null
    $newest = $null

    # Find oldest from start
    foreach($line in $LogFileLines) {
        if($line -match $Script:IntuneHarvesterUSARegex) {
            try {
                $Hour = [int]$Matches[4]
                $AMPM = $Matches[7]
                if($AMPM -eq 'AM' -and $Hour -eq 12) { $Hour = 0 }
                elseif($AMPM -eq 'PM' -and $Hour -ne 12) { $Hour = $Hour + 12 }
                $oldest = Get-Date -Year $Matches[3] -Month $Matches[1] -Day $Matches[2] -Hour $Hour -Minute $Matches[5] -Second $Matches[6] -ErrorAction Stop
                break
            } catch { continue }
        }
    }

    # Find newest from end
    for($i = $LogFileLines.Count - 1; $i -ge 0; $i--) {
        if($LogFileLines[$i] -match $Script:IntuneHarvesterUSARegex) {
            try {
                $Hour = [int]$Matches[4]
                $AMPM = $Matches[7]
                if($AMPM -eq 'AM' -and $Hour -eq 12) { $Hour = 0 }
                elseif($AMPM -eq 'PM' -and $Hour -ne 12) { $Hour = $Hour + 12 }
                $newest = Get-Date -Year $Matches[3] -Month $Matches[1] -Day $Matches[2] -Hour $Hour -Minute $Matches[5] -Second $Matches[6] -ErrorAction Stop
                break
            } catch { continue }
        }
    }

    return @{ Oldest = $oldest; Newest = $newest }
}

function Read-IntuneInventoryHarvesterUSALogEntries {
    param(
        [Parameter(Mandatory=$true)] [AllowEmptyString()] [string[]]$LogFileLines,
        [Parameter(Mandatory=$true)] $StartTimeObject,
        [Parameter(Mandatory=$true)] $EndTimeObject,
        [Parameter(Mandatory=$true)] [string]$LogFileName,
        [Parameter(Mandatory=$false)] [AllowEmptyCollection()] [array]$KnownLogEventRuleObjects = @(),
        [Parameter(Mandatory=$false)] [bool]$AllEvents = $false
    )

    $entries = @()
    $lineNumber = 0
    $consecutiveFailures = 0

    foreach($line in $LogFileLines) {
        $lineNumber++

        if($consecutiveFailures -ge 20) {
            Write-Verbose "IntuneInventoryHarvesterUSA parser: Too many consecutive parse failures, stopping"
            break
        }

        if($line -match $Script:IntuneHarvesterUSARegex) {
            $consecutiveFailures = 0

            $Month = $Matches[1]; $Day = $Matches[2]; $Year = $Matches[3]
            $Hour = [int]$Matches[4]; $Minute = $Matches[5]; $Second = $Matches[6]
            $AMPM = $Matches[7]
            $LevelDisplayName = $Matches[8]
            $LogMessage = $Matches[9].Trim()
            $Component = 'InventoryHarvester'

            # Convert 12-hour clock to 24-hour clock
            # Handle 12 AM (midnight=0) and 12 PM (noon=12) correctly
            if($AMPM -eq 'AM' -and $Hour -eq 12) { $Hour = 0 }
            elseif($AMPM -eq 'PM' -and $Hour -ne 12) { $Hour = $Hour + 12 }

            try {
                $dateObj = Get-Date -Year $Year -Month $Month -Day $Day -Hour $Hour -Minute $Minute -Second $Second -ErrorAction Stop
            } catch { continue }

            if($dateObj -lt $StartTimeObject -or $dateObj -gt $EndTimeObject) { continue }

            $dateStr = Format-DateTimeForTimeline -Year $Year -Month $Month -Day $Day -Hour ([string]$Hour) -Minute $Minute -Second $Second

            # Check event rules
            $ruleMatch = Match-EventRulesForLogEntry -LogMessage $LogMessage -KnownLogEventRuleObjects $KnownLogEventRuleObjects

            if($ruleMatch) {
                $entries += @{
                    DateTimeObject = $dateObj
                    Date = $dateStr
                    LogName = $LogFileName
                    ProviderName = $Component
                    Id = ''
                    LevelDisplayName = $LevelDisplayName
                    Message = $LogMessage
                    EventNumber = $lineNumber
                    Color = $ruleMatch.Color
                    MessageToolTip = $ruleMatch.MessageToolTip
                    KnownCategoryName = $ruleMatch.CategoryName
                }
            } elseif($AllEvents) {
                $entries += @{
                    DateTimeObject = $dateObj
                    Date = $dateStr
                    LogName = $LogFileName
                    ProviderName = $Component
                    Id = ''
                    LevelDisplayName = $LevelDisplayName
                    Message = $LogMessage
                    EventNumber = $lineNumber
                    Color = $null
                    MessageToolTip = $null
                    KnownCategoryName = $null
                }
            }
        } else {
            if($line.Trim().Length -gt 0) {
                $consecutiveFailures++
            }
        }
    }

    return $entries
}
