# Parser-SetupAPI.ps1
# Parser for SetupAPI section-based log files
# Handles: setupapi.dev.log, setupapi.setup.log
# Part of Get-WindowsTroubleshootingReportCommunity v3.0
#
# Format: Section-based with >>> (start) and <<< (end) markers
# Section start: >>>  [Section Title - Instance]
# Timestamp: >>>  Section start YYYY/MM/DD HH:MM:SS.mmm

$Script:SetupAPISectionStartRegex = '^\s*>>>\s+\[(.+?)(?:\s-\s(.+))?\]\s*$'
$Script:SetupAPITimestampRegex = '^\s*[><]{3}\s+Section\s+(?:start|end)\s+(\d{4})/(\d{2})/(\d{2})\s+(\d{2}):(\d{2}):(\d{2})\.(\d{3})'
$Script:SetupAPIExitStatusRegex = '^\s*<<<\s+\[Exit status:\s+(.+?)\]\s*$'

function Test-SetupAPIFormat {
    param([string[]]$Lines)
    foreach($line in $Lines) {
        if($line -match '^\s*>>>') { return $true }
    }
    return $false
}

function Get-SetupAPITimeRange {
    param(
        [Parameter(Mandatory=$true)] [AllowEmptyString()] [string[]]$LogFileLines
    )

    $oldest = $null
    $newest = $null

    foreach($line in $LogFileLines) {
        if($line -match $Script:SetupAPITimestampRegex) {
            try {
                $oldest = Get-Date -Year $Matches[1] -Month $Matches[2] -Day $Matches[3] -Hour $Matches[4] -Minute $Matches[5] -Second $Matches[6] -Millisecond $Matches[7] -ErrorAction Stop
                break
            } catch { continue }
        }
    }

    for($i = $LogFileLines.Count - 1; $i -ge 0; $i--) {
        if($LogFileLines[$i] -match $Script:SetupAPITimestampRegex) {
            try {
                $newest = Get-Date -Year $Matches[1] -Month $Matches[2] -Day $Matches[3] -Hour $Matches[4] -Minute $Matches[5] -Second $Matches[6] -Millisecond $Matches[7] -ErrorAction Stop
                break
            } catch { continue }
        }
    }

    return @{ Oldest = $oldest; Newest = $newest }
}

function Read-SetupAPILogEntries {
    <#
    .SYNOPSIS
        Parses SetupAPI section-based log files
    .DESCRIPTION
        Groups log lines into sections bounded by >>> and <<<.
        Each section becomes a timeline entry with the section title as ProviderName
        and the exit status determining color (FAILURE → Red).
    #>
    param(
        [Parameter(Mandatory=$true)] [AllowEmptyString()] [string[]]$LogFileLines,
        [Parameter(Mandatory=$true)] $StartTimeObject,
        [Parameter(Mandatory=$true)] $EndTimeObject,
        [Parameter(Mandatory=$true)] [string]$LogFileName,
        [Parameter(Mandatory=$false)] [array]$KnownLogEventRuleObjects = @(),
        [Parameter(Mandatory=$false)] [bool]$AllEvents = $false
    )

    $entries = @()
    $lineNumber = 0
    $currentSection = $null
    $sectionTitle = ''
    $sectionInstance = ''
    $sectionStartTime = $null
    $sectionBody = @()

    foreach($line in $LogFileLines) {
        $lineNumber++
        $line = $line -replace "^\uFEFF", ""

        # New section start
        if($line -match $Script:SetupAPISectionStartRegex) {
            $sectionTitle = $Matches[1]
            $sectionInstance = if($Matches[2]) { $Matches[2] } else { '' }
            $sectionBody = @()
            $sectionStartTime = $null
            continue
        }

        # Section start timestamp
        if($line -match '^\s*>>>\s+Section start' -and $line -match $Script:SetupAPITimestampRegex) {
            try {
                $sectionStartTime = Get-Date -Year $Matches[1] -Month $Matches[2] -Day $Matches[3] -Hour $Matches[4] -Minute $Matches[5] -Second $Matches[6] -Millisecond $Matches[7] -ErrorAction Stop
            } catch { }
            continue
        }

        # Section body line
        if($line -match '^\s{5}\S') {
            $sectionBody += $line.TrimStart()
        }

        # Section end + exit status
        if($line -match $Script:SetupAPIExitStatusRegex) {
            $exitStatus = $Matches[1]

            if(-not $sectionStartTime) { continue }
            if($sectionStartTime -lt $StartTimeObject -or $sectionStartTime -gt $EndTimeObject) { continue }

            $color = $null
            $levelDisplay = 'Information'
            if($exitStatus -match 'FAILURE') {
                $color = 'Red'
                $levelDisplay = 'Error'
            } elseif($exitStatus -eq 'SUCCESS') {
                $levelDisplay = 'Information'
            }

            $message = "[$sectionTitle"
            if($sectionInstance) { $message += " - $sectionInstance" }
            $message += "] Exit: $exitStatus"
            if($sectionBody.Count -gt 0) {
                # Add key body lines (limit to avoid huge messages)
                $bodyPreview = ($sectionBody | Select-Object -First 10) -join "`n"
                $message += "`n$bodyPreview"
                if($sectionBody.Count -gt 10) {
                    $message += "`n... ($($sectionBody.Count - 10) more lines)"
                }
            }

            $Year = $sectionStartTime.Year.ToString()
            $Month = $sectionStartTime.Month.ToString()
            $Day = $sectionStartTime.Day.ToString()
            $Hour = $sectionStartTime.Hour.ToString()
            $Minute = $sectionStartTime.Minute.ToString()
            $Second = $sectionStartTime.Second.ToString()
            $Millisecond = $sectionStartTime.Millisecond.ToString()

            $dateStr = Format-DateTimeForTimeline -Year $Year -Month $Month -Day $Day -Hour $Hour -Minute $Minute -Second $Second -Millisecond $Millisecond

            $entry = @{
                DateTimeObject = $sectionStartTime
                Date = $dateStr
                LogName = $LogFileName
                ProviderName = $sectionTitle
                Id = ''
                LevelDisplayName = $levelDisplay
                Message = $message
                Color = $color
                EventNumber = $lineNumber
                MessageToolTip = $null
                KnownCategoryName = $null
            }

            # Check EventRules
            $ruleMatch = Match-EventRulesForLogEntry -LogMessage $message -KnownLogEventRuleObjects $KnownLogEventRuleObjects
            if($ruleMatch) {
                $entry.Color = $ruleMatch.Color
                $entry.MessageToolTip = $ruleMatch.MessageToolTip
                $entry.KnownCategoryName = $ruleMatch.CategoryName
                $entries += $entry
            } elseif($AllEvents -or $color -eq 'Red') {
                # Always show failures; show all if AllEvents
                $entries += $entry
            }

            # Reset section
            $sectionTitle = ''
            $sectionInstance = ''
            $sectionBody = @()
            $sectionStartTime = $null
        }
    }

    return $entries
}
