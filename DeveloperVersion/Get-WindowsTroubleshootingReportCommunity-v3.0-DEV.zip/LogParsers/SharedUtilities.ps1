# SharedUtilities.ps1
# Shared utility functions used by all log parsers
# Part of Get-WindowsTroubleshootingReportCommunity v3.0
#
# These functions are dot-sourced into the main script

function ConvertTo-SafeRegexPattern {
    <#
    .SYNOPSIS
        Escapes a string for use as a regex pattern, preserving intentional .* wildcards
    .DESCRIPTION
        If the input starts or ends with .*, those wildcards are preserved.
        All other regex special characters are escaped.
        This is used when processing EventRules Message patterns.
    #>
    param(
        [Parameter(Mandatory=$true)]
        [string]$Pattern
    )

    $startsWithDotStar = $Pattern.StartsWith('.*')
    $endsWithDotStar = $Pattern.EndsWith('.*')

    if ($startsWithDotStar) {
        $Pattern = $Pattern.Substring(2)
    }
    if ($endsWithDotStar) {
        $Pattern = $Pattern.Substring(0, $Pattern.Length - 2)
    }

    $escapedPattern = [regex]::Escape($Pattern)

    if ($startsWithDotStar) {
        $escapedPattern = '.*' + $escapedPattern
    }
    if ($endsWithDotStar) {
        $escapedPattern = $escapedPattern + '.*'
    }

    return $escapedPattern
}


function Convert-12HourTo24Hour {
    <#
    .SYNOPSIS
        Converts 12-hour clock values to 24-hour format
    .DESCRIPTION
        Handles the edge cases: 12 AM = 0, 12 PM = 12, other PM hours add 12
    #>
    param(
        [Parameter(Mandatory=$true)]
        [int]$Hour,
        [Parameter(Mandatory=$true)]
        [ValidateSet('AM','PM')]
        [string]$AMPM
    )

    if($AMPM -eq 'AM' -and $Hour -eq 12) { return 0 }
    elseif($AMPM -eq 'PM' -and $Hour -ne 12) { return $Hour + 12 }
    else { return $Hour }
}


function Format-DateTimeForTimeline {
    <#
    .SYNOPSIS
        Formats date/time components into a sortable string for the timeline
    .DESCRIPTION
        Creates yyyy-MM-dd HH:mm:ss format with proper zero-padding.
        Optionally includes milliseconds.
    #>
    param(
        [Parameter(Mandatory=$true)] [string]$Year,
        [Parameter(Mandatory=$true)] [string]$Month,
        [Parameter(Mandatory=$true)] [string]$Day,
        [Parameter(Mandatory=$true)] [string]$Hour,
        [Parameter(Mandatory=$true)] [string]$Minute,
        [Parameter(Mandatory=$true)] [string]$Second,
        [Parameter(Mandatory=$false)] [string]$Millisecond = $null
    )

    # Add leading 0 so sorting works right
    if($Hour.Length -eq 1) { $Hour = "0$Hour" }
    if($Minute.Length -eq 1) { $Minute = "0$Minute" }
    if($Second.Length -eq 1) { $Second = "0$Second" }
    if($Month.Length -eq 1) { $Month = "0$Month" }
    if($Day.Length -eq 1) { $Day = "0$Day" }

    if($Millisecond) {
        return "$Year-$Month-$Day $($Hour):$($Minute):$($Second).$Millisecond"
    } else {
        return "$Year-$Month-$Day $($Hour):$($Minute):$($Second)"
    }
}


function Get-LogFileEncoding {
    <#
    .SYNOPSIS
        Detects file encoding by checking BOM (Byte Order Mark)
    .DESCRIPTION
        Reads the first bytes of a file to detect UTF-8 BOM, UTF-16 LE BOM, or UTF-16 BE BOM.
        Returns the appropriate encoding name for Get-Content -Encoding parameter.
    #>
    param(
        [Parameter(Mandatory=$true)]
        [string]$Path
    )

    try {
        $bytes = [System.IO.File]::ReadAllBytes($Path)
        
        if($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {
            return 'UTF8'
        }
        elseif($bytes.Length -ge 2 -and $bytes[0] -eq 0xFF -and $bytes[1] -eq 0xFE) {
            return 'Unicode'  # UTF-16 LE
        }
        elseif($bytes.Length -ge 2 -and $bytes[0] -eq 0xFE -and $bytes[1] -eq 0xFF) {
            return 'BigEndianUnicode'  # UTF-16 BE
        }
        else {
            return 'Default'  # System default (usually ANSI/ASCII)
        }
    } catch {
        return 'Default'
    }
}


function Read-LogFileWithEncoding {
    <#
    .SYNOPSIS
        Reads a log file with automatic encoding detection
    .DESCRIPTION
        Detects the encoding and reads the file content.
        Handles UTF-16 LE files (like PFRO.log, SrtTrail.txt) that require special encoding.
    #>
    param(
        [Parameter(Mandatory=$true)]
        [string]$Path
    )

    $encoding = Get-LogFileEncoding -Path $Path

    try {
        $lines = Get-Content -Path $Path -Encoding $encoding -ErrorAction Stop
        return $lines
    } catch {
        # Fallback to default encoding
        try {
            $lines = Get-Content -Path $Path -ErrorAction Stop
            return $lines
        } catch {
            Write-Host "ERROR: Could not read log file with any encoding: $Path" -ForegroundColor 'Red'
            return $null
        }
    }
}


function Get-LogFilePreview {
    <#
    .SYNOPSIS
        Reads the first N lines and first 512+ bytes of a file for format auto-detection
    .DESCRIPTION
        Used by Detect-LogFileFormat to quickly identify what format a log file is in
        without reading the entire file.
    #>
    param(
        [Parameter(Mandatory=$true)]
        [string]$Path,
        [Parameter(Mandatory=$false)]
        [int]$MaxLines = 30,
        [Parameter(Mandatory=$false)]
        [int]$MaxBytes = 1024
    )

    $result = @{
        Lines = @()
        RawBytes = @()
        RawText = ''
    }

    try {
        # Read first N lines
        $result.Lines = Get-Content -Path $Path -TotalCount $MaxLines -ErrorAction Stop

        # Read first bytes for BOM/binary detection
        $stream = [System.IO.File]::OpenRead($Path)
        $buffer = New-Object byte[] ([Math]::Min($MaxBytes, $stream.Length))
        $null = $stream.Read($buffer, 0, $buffer.Length)
        $stream.Close()
        $result.RawBytes = $buffer

        # Convert to text for pattern matching
        $result.RawText = [System.Text.Encoding]::UTF8.GetString($buffer)
    } catch {
        Write-Verbose "Could not preview file: $Path - $_"
    }

    return $result
}


function Match-EventRulesForLogEntry {
    <#
    .SYNOPSIS
        Checks a log message against the known EventRules and returns matching rule info
    .DESCRIPTION
        Iterates through the applicable event rules for a log file type and returns
        the first matching rule's Color, ToolTipText, and CategoryName.
        Returns $null if no match found.
    #>
    param(
        [Parameter(Mandatory=$true)]
        # [AllowEmptyString()] is required here.
        # Some ETL events (header/metadata records, events from unregistered providers
        # with empty BinaryEventData) produce a zero-length message string. Without this
        # attribute, PowerShell rejects the empty string with a parameter-binding exception.
        # In the streaming path of Read-XMLLogEntries that exception is caught by the outer
        # try/catch, silently aborting the entire loop after the first empty-message event.
        [AllowEmptyString()]
        [string]$LogMessage,
        [Parameter(Mandatory=$false)]
        [AllowEmptyCollection()]
        [array]$KnownLogEventRuleObjects = @()
    )

    if(-not $KnownLogEventRuleObjects -or $KnownLogEventRuleObjects.Count -eq 0) { return $null }

    foreach($rule in $KnownLogEventRuleObjects) {
        if($LogMessage -match $rule.Message) {
            return @{
                Color = if($rule.Color) { $rule.Color } else { $null }
                MessageToolTip = if($rule.ToolTipText) { $rule.ToolTipText } else { $null }
                CategoryName = $rule.CategoryName
            }
        }
    }

    return $null
}
