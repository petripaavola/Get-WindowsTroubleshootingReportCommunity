# Parser-MSI.ps1
# Parser for Windows Installer (MSI) log files
# Handles: MSI*.LOG files with multi-format content
# Part of Get-WindowsTroubleshootingReportCommunity v3.0
#
# MSI logs have no single consistent line format. They alternate between:
# - MSI engine lines: MSI (s) (PID:TID) [HH:MM:SS:mmm]: message
# - Action lines: Action start HH:MM:SS: ActionName.
# - Property lines: Property(S): Name = Value
# - Raw output: no prefix (custom action stdout/stderr)

$Script:MSIEngineLineRegex = '^MSI\s\([sc]\)\s\(([0-9A-Fa-f]+:[0-9A-Fa-f]+)\)\s\[(\d{2}):(\d{2}):(\d{2}):(\d{3})\]:\s(.+)$'
$Script:MSIActionLineRegex = '^Action\s(?:start\s|ended\s)?(\d{2}):(\d{2}):(\d{2}):\s(\w+)\.?\s?(?:Return value (\d)\.)?$'
$Script:MSIHeaderRegex = '^===\s+Verbose logging started:\s+(\d{1,2})/(\d{1,2})/(\d{4})\s+(\d{1,2}):(\d{2}):(\d{2})'

function Test-MSIFormat {
    param([string[]]$Lines)
    if($Lines.Count -gt 0 -and $Lines[0] -match '^===') { return $true }
    foreach($line in $Lines) {
        if($line -match '^MSI \([sc]\)') { return $true }
    }
    return $false
}

function Get-MSITimeRange {
    param(
        [Parameter(Mandatory=$true)] [AllowEmptyString()] [string[]]$LogFileLines
    )

    $oldest = $null
    $newest = $null
    $baseDate = $null

    # Extract base date from header line
    foreach($line in $LogFileLines) {
        if($line -match $Script:MSIHeaderRegex) {
            try {
                $baseDate = Get-Date -Month $Matches[1] -Day $Matches[2] -Year $Matches[3] -Hour $Matches[4] -Minute $Matches[5] -Second $Matches[6] -ErrorAction Stop
                $oldest = $baseDate
                break
            } catch { continue }
        }
    }

    # Find newest from last MSI engine line or action line
    for($i = $LogFileLines.Count - 1; $i -ge 0; $i--) {
        $line = $LogFileLines[$i]
        if($line -match $Script:MSIEngineLineRegex) {
            if($baseDate) {
                try {
                    $newest = Get-Date -Year $baseDate.Year -Month $baseDate.Month -Day $baseDate.Day -Hour $Matches[2] -Minute $Matches[3] -Second $Matches[4] -Millisecond $Matches[5] -ErrorAction Stop
                    break
                } catch { continue }
            }
        }
        if($line -match $Script:MSIActionLineRegex) {
            if($baseDate) {
                try {
                    $newest = Get-Date -Year $baseDate.Year -Month $baseDate.Month -Day $baseDate.Day -Hour $Matches[1] -Minute $Matches[2] -Second $Matches[3] -ErrorAction Stop
                    break
                } catch { continue }
            }
        }
        if($line -match '^===\s+Verbose logging stopped:') {
            # Footer has similar date format
            if($line -match '(\d{1,2})/(\d{1,2})/(\d{4})\s+(\d{1,2}):(\d{2}):(\d{2})') {
                try {
                    $newest = Get-Date -Month $Matches[1] -Day $Matches[2] -Year $Matches[3] -Hour $Matches[4] -Minute $Matches[5] -Second $Matches[6] -ErrorAction Stop
                    break
                } catch { continue }
            }
        }
    }

    return @{ Oldest = $oldest; Newest = $newest }
}

function Read-MSILogEntries {
    <#
    .SYNOPSIS
        Parses MSI installer log files
    .DESCRIPTION
        Classifies each line by prefix pattern, extracts timestamps.
        Flags Return value 3 (fatal error) as Red.
    #>
    param(
        [Parameter(Mandatory=$true)] [AllowEmptyString()] [string[]]$LogFileLines,
        [Parameter(Mandatory=$true)] $StartTimeObject,
        [Parameter(Mandatory=$true)] $EndTimeObject,
        [Parameter(Mandatory=$true)] [string]$LogFileName,
        [Parameter(Mandatory=$false)] [array]$KnownLogEventRuleObjects = @(),
        [Parameter(Mandatory=$false)] [bool]$AllEvents = $false
    )

    $entries = @()
    $lineNumber = 0
    $baseDate = $null

    foreach($line in $LogFileLines) {
        $lineNumber++
        $line = $line -replace "^\uFEFF", ""

        # Extract base date from header
        if($line -match $Script:MSIHeaderRegex) {
            try {
                $baseDate = Get-Date -Month $Matches[1] -Day $Matches[2] -Year $Matches[3] -Hour $Matches[4] -Minute $Matches[5] -Second $Matches[6] -ErrorAction Stop
            } catch { }
            continue
        }

        if(-not $baseDate) { continue }

        $dateObj = $null
        $message = $null
        $component = 'MSI'
        $color = $null
        $levelDisplay = 'Information'

        # MSI engine line
        if($line -match $Script:MSIEngineLineRegex) {
            $pidTid = $Matches[1]
            $Hour = $Matches[2]; $Minute = $Matches[3]; $Second = $Matches[4]; $Millisecond = $Matches[5]
            $message = $Matches[6]
            $component = "MSI($pidTid)"

            try {
                $dateObj = Get-Date -Year $baseDate.Year -Month $baseDate.Month -Day $baseDate.Day -Hour $Hour -Minute $Minute -Second $Second -Millisecond $Millisecond -ErrorAction Stop
            } catch { continue }
        }
        # Action line
        elseif($line -match $Script:MSIActionLineRegex) {
            $Hour = $Matches[1]; $Minute = $Matches[2]; $Second = $Matches[3]
            $actionName = $Matches[4]
            $returnValue = $Matches[5]

            $message = $line
            $component = 'MSI-Action'

            if($returnValue -eq '3') {
                $color = 'Red'
                $levelDisplay = 'Error'
            } elseif($returnValue -eq '2') {
                $color = 'Yellow'
                $levelDisplay = 'Warning'
            }

            try {
                $dateObj = Get-Date -Year $baseDate.Year -Month $baseDate.Month -Day $baseDate.Day -Hour $Hour -Minute $Minute -Second $Second -ErrorAction Stop
            } catch { continue }
        }
        else {
            # Property lines, raw output - skip unless AllEvents
            if(-not $AllEvents) { continue }
            # Use base date for undated lines
            $dateObj = $baseDate
            $message = $line
            $component = 'MSI-Output'
        }

        if(-not $dateObj -or -not $message) { continue }
        if($dateObj -lt $StartTimeObject -or $dateObj -gt $EndTimeObject) { continue }

        $Year = $dateObj.Year.ToString(); $Month = $dateObj.Month.ToString(); $Day = $dateObj.Day.ToString()
        $HourStr = $dateObj.Hour.ToString(); $MinuteStr = $dateObj.Minute.ToString(); $SecondStr = $dateObj.Second.ToString()
        $dateTimeline = Format-DateTimeForTimeline -Year $Year -Month $Month -Day $Day -Hour $HourStr -Minute $MinuteStr -Second $SecondStr

        $entry = @{
            DateTimeObject = $dateObj
            Date = $dateTimeline
            LogName = $LogFileName
            ProviderName = $component
            Id = ''
            LevelDisplayName = $levelDisplay
            Message = $message
            Color = $color
            EventNumber = $lineNumber
            MessageToolTip = $null
            KnownCategoryName = $null
        }

        $ruleMatch = Match-EventRulesForLogEntry -LogMessage $message -KnownLogEventRuleObjects $KnownLogEventRuleObjects
        if($ruleMatch) {
            $entry.Color = $ruleMatch.Color
            $entry.MessageToolTip = $ruleMatch.MessageToolTip
            $entry.KnownCategoryName = $ruleMatch.CategoryName
            $entries += $entry
        } elseif($AllEvents -or $color) {
            $entries += $entry
        }
    }

    return $entries
}
