# Parser-IntuneInventoryAdaptor.ps1
# Parser for Intune Custom Inventory Adaptor log files
# Part of Get-WindowsTroubleshootingReportCommunity v3.0
#
# Line Format: [Weekday Mon  DD HH:MM:SS YYYY][ThreadID] - Message
# Example: [Fri May  2 21:51:08 2025][692480] - ===== Starting ExecuteAction =====
# Example: [Thu Dec 19 08:51:03 2024][16360] - ===== Starting ExecuteAction =====

$Script:IntuneInventoryAdaptorRegex = '^\[(\w+)\s+(\w+)\s+(\d+)\s+(\d{2}):(\d{2}):(\d{2})\s+(\d{4})\]\[(\d+)\] - (.*)$'

function ConvertFrom-MonthAbbreviation {
    param([string]$MonthName)
    switch($MonthName) {
        'Jan' { 1 }
        'Feb' { 2 }
        'Mar' { 3 }
        'Apr' { 4 }
        'May' { 5 }
        'Jun' { 6 }
        'Jul' { 7 }
        'Aug' { 8 }
        'Sep' { 9 }
        'Oct' { 10 }
        'Nov' { 11 }
        'Dec' { 12 }
        default { $null }
    }
}

function Test-IntuneInventoryAdaptorFormat {
    param([string[]]$Lines)
    foreach($line in $Lines) {
        if($line -match $Script:IntuneInventoryAdaptorRegex) { return $true }
    }
    return $false
}

function Get-IntuneInventoryAdaptorTimeRange {
    param(
        [Parameter(Mandatory=$true)] [AllowEmptyString()] [string[]]$LogFileLines
    )

    $oldest = $null
    $newest = $null

    # Find oldest from start
    foreach($line in $LogFileLines) {
        if($line -match $Script:IntuneInventoryAdaptorRegex) {
            $Month = ConvertFrom-MonthAbbreviation -MonthName $Matches[2]
            if($null -eq $Month) { continue }
            try {
                $oldest = Get-Date -Year $Matches[7] -Month $Month -Day $Matches[3] -Hour $Matches[4] -Minute $Matches[5] -Second $Matches[6] -ErrorAction Stop
                break
            } catch { continue }
        }
    }

    # Find newest from end
    for($i = $LogFileLines.Count - 1; $i -ge 0; $i--) {
        if($LogFileLines[$i] -match $Script:IntuneInventoryAdaptorRegex) {
            $Month = ConvertFrom-MonthAbbreviation -MonthName $Matches[2]
            if($null -eq $Month) { continue }
            try {
                $newest = Get-Date -Year $Matches[7] -Month $Month -Day $Matches[3] -Hour $Matches[4] -Minute $Matches[5] -Second $Matches[6] -ErrorAction Stop
                break
            } catch { continue }
        }
    }

    return @{ Oldest = $oldest; Newest = $newest }
}

function Read-IntuneInventoryAdaptorLogEntries {
    param(
        [Parameter(Mandatory=$true)] [AllowEmptyString()] [string[]]$LogFileLines,
        [Parameter(Mandatory=$true)] $StartTimeObject,
        [Parameter(Mandatory=$true)] $EndTimeObject,
        [Parameter(Mandatory=$true)] [string]$LogFileName,
        [Parameter(Mandatory=$false)] [AllowEmptyCollection()] [array]$KnownLogEventRuleObjects = @(),
        [Parameter(Mandatory=$false)] [bool]$AllEvents = $false
    )

    $entries = @()
    $lineNumber = 0
    $consecutiveFailures = 0

    foreach($line in $LogFileLines) {
        $lineNumber++

        if($consecutiveFailures -ge 20) {
            Write-Verbose "IntuneInventoryAdaptor parser: Too many consecutive parse failures, stopping"
            break
        }

        if($line -match $Script:IntuneInventoryAdaptorRegex) {
            $consecutiveFailures = 0

            $MonthNameAsText = $Matches[2]
            $Month = ConvertFrom-MonthAbbreviation -MonthName $MonthNameAsText
            if($null -eq $Month) { continue }

            $Day = $Matches[3]
            $Hour = $Matches[4]; $Minute = $Matches[5]; $Second = $Matches[6]
            $Year = $Matches[7]
            $ID = $Matches[8]
            $LogMessage = $Matches[9].Trim()
            $Component = 'InventoryAdaptor'

            try {
                $dateObj = Get-Date -Year $Year -Month $Month -Day $Day -Hour $Hour -Minute $Minute -Second $Second -ErrorAction Stop
            } catch { continue }

            if($dateObj -lt $StartTimeObject -or $dateObj -gt $EndTimeObject) { continue }

            $dateStr = Format-DateTimeForTimeline -Year $Year -Month ([string]$Month) -Day $Day -Hour $Hour -Minute $Minute -Second $Second

            # Check event rules
            $ruleMatch = Match-EventRulesForLogEntry -LogMessage $LogMessage -KnownLogEventRuleObjects $KnownLogEventRuleObjects

            if($ruleMatch) {
                $entries += @{
                    DateTimeObject = $dateObj
                    Date = $dateStr
                    LogName = $LogFileName
                    ProviderName = $Component
                    Id = $ID
                    LevelDisplayName = ''
                    Message = $LogMessage
                    EventNumber = $lineNumber
                    Color = $ruleMatch.Color
                    MessageToolTip = $ruleMatch.MessageToolTip
                    KnownCategoryName = $ruleMatch.CategoryName
                }
            } elseif($AllEvents) {
                $entries += @{
                    DateTimeObject = $dateObj
                    Date = $dateStr
                    LogName = $LogFileName
                    ProviderName = $Component
                    Id = $ID
                    LevelDisplayName = ''
                    Message = $LogMessage
                    EventNumber = $lineNumber
                    Color = $null
                    MessageToolTip = $null
                    KnownCategoryName = $null
                }
            }
        } else {
            if($line.Trim().Length -gt 0) {
                $consecutiveFailures++
            }
        }
    }

    return $entries
}
