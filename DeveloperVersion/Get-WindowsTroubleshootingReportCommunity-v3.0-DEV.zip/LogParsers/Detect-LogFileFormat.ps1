# Detect-LogFileFormat.ps1
# Auto-detection dispatcher for log file formats
# Part of Get-WindowsTroubleshootingReportCommunity v3.0
#
# Detection priority order follows the log-format-reference algorithm:
# https://github.com/adamgell/cmtraceopen/blob/main/references/log-format-reference.md

function Detect-LogFileFormat {
    <#
    .SYNOPSIS
        Auto-detects the format of a log file by examining its content
    .DESCRIPTION
        Reads the first portion of a file and tests against known format signatures
        in priority order. Returns the format identifier string.
    .OUTPUTS
        String - one of: 'XML', 'CMTrace', 'W3C', 'SetupAPI', 'MSI', 'ReportingEvents',
                         'CBS', 'WindowsUpdate', 'DirectX', 'PFRO',
                         'IntuneCustomInventoryAdaptor', 'IntuneCustomInventoryHarvesterNonUSA',
                         'IntuneCustomInventoryHarvesterUSA', 'OfficeC2R', 'ETL', 'PlainText',
                         or $null if file cannot be read
    #>
    param(
        [Parameter(Mandatory=$true)]
        [string]$Path,
        [Parameter(Mandatory=$false)]
        [string[]]$FileLines = $null
    )

    # If lines not provided, read a preview
    if(-not $FileLines -or $FileLines.Count -eq 0) {
        try {
            $FileLines = Get-Content -Path $Path -TotalCount 50 -ErrorAction Stop
        } catch {
            Write-Verbose "Detect-LogFileFormat: Cannot read file: $Path"
            return $null
        }
    }

    # Get file extension for ETL detection
    $extension = [System.IO.Path]::GetExtension($Path).ToLower()

    # ETL files are binary - detect by extension before text-based detection
    if($extension -eq '.etl') {
        return 'ETL'
    }

    # Get first non-empty lines for pattern matching
    $previewLines = $FileLines | Where-Object { $_ -and $_.Trim().Length -gt 0 } | Select-Object -First 30

    if(-not $previewLines -or $previewLines.Count -eq 0) {
        return $null
    }

    $firstLine = $previewLines[0]
    $joinedPreview = $previewLines -join "`n"

    # 1. XML detection - starts with <?xml or BOM + <?xml
    $cleanFirstLine = $firstLine -replace "^\uFEFF", ""
    if($cleanFirstLine.TrimStart().StartsWith('<?xml') -or $cleanFirstLine.TrimStart().StartsWith('<Collection') -or $cleanFirstLine.TrimStart().StartsWith('<Results')) {
        return 'XML'
    }

    # 2. CMTrace format - contains <![LOG[ signature
    # This is the most specific signature - check early
    foreach($line in $previewLines) {
        if($line -match '<!\[LOG\[') {
            return 'CMTrace'
        }
        # Also check for CMTrace multiline start pattern
        if($line -match '^\<\!\[LOG\[') {
            return 'CMTrace'
        }
    }

    # 3. W3C Extended Log File Format - has #Version: or #Fields: headers
    foreach($line in $previewLines) {
        if($line -match '^#Version:' -or $line -match '^#Fields:') {
            return 'W3C'
        }
    }

    # 4. SetupAPI section-based format - >>> markers
    foreach($line in $previewLines) {
        if($line -match '^\s*>>>') {
            return 'SetupAPI'
        }
    }

    # 5. MSI logs - starts with === or contains MSI (s) / MSI (c)
    if($cleanFirstLine -match '^===') {
        return 'MSI'
    }
    foreach($line in $previewLines) {
        if($line -match '^MSI \([sc]\)') {
            return 'MSI'
        }
    }

    # 6. ReportingEvents.log - tab-delimited, starts with {GUID}
    if($firstLine -match '^\{[0-9a-fA-F]{8}-' -and $firstLine -match '\t') {
        return 'ReportingEvents'
    }

    # 7. CBS/Panther format - YYYY-MM-DD HH:MM:SS, Level
    foreach($line in $previewLines) {
        if($line -match '^\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2},\s+(Info|Error|Warning|Perf)') {
            return 'CBS'
        }
    }

    # 8. WindowsUpdate.log - YYYY-MM-DD or YYYY/MM/DD  HH:MM:SS.NNN-NNNNNNN (3-7 digit precision)
    foreach($line in $previewLines) {
        if($line -match '^\d{4}[-/]\d{2}[-/]\d{2}\s\d{2}:\d{2}:\d{2}[.:]\d{3,7}\s+\d+\s+\d+\s+\S') {
            return 'WindowsUpdate'
        }
    }

    # 9. Intune InventoryAdaptor - [Weekday Mon DD HH:MM:SS YYYY][ThreadID] - Message
    foreach($line in $previewLines) {
        if($line -match '^\[\w+\s+\w+\s+\d+\s+\d{2}:\d{2}:\d{2}\s+\d{4}\]\[\d+\] - ') {
            return 'IntuneCustomInventoryAdaptor'
        }
    }

    # 10. Intune InventoryHarvester Non-USA - DD.MM.YYYY HH.MM.SS [Level]
    foreach($line in $previewLines) {
        if($line -match '^\d{1,2}\.\d{1,2}\.\d{4}\s+\d{1,2}\.\d{1,2}\.\d{1,2}\s+\[\w+\]') {
            return 'IntuneCustomInventoryHarvesterNonUSA'
        }
    }

    # 11. Intune InventoryHarvester USA - MM/DD/YYYY HH:MM:SS AM/PM [Level]
    foreach($line in $previewLines) {
        if($line -match '^\d{1,2}/\d{1,2}/\d{4}\s+\d{1,2}:\d{1,2}:\d{1,2}\s+(AM|PM)\s+\[\w+\]') {
            return 'IntuneCustomInventoryHarvesterUSA'
        }
    }

    # 12. DirectX.log - MM/DD/YYYY HH:MM:SS: component:
    foreach($line in $previewLines) {
        if($line -match '^\d{2}/\d{2}/\d{4}\s\d{2}:\d{2}:\d{2}:\s\w+:') {
            return 'DirectX'
        }
    }

    # 13. PFRO.log - YYYY/MM/DD HH:MM:SS.mmm (3-digit milliseconds, typically UTF-16 LE)
    foreach($line in $previewLines) {
        if($line -match '^\d{4}/\d{2}/\d{2}\s\d{2}:\d{2}:\d{2}\.\d{3}\s') {
            return 'PFRO'
        }
    }

    # 14. Office C2R - tab-separated headers
    $OfficeC2RHeaders = 'Timestamp	Process	TID	Area	Category	EventID	Level	Message	Correlation'
    if($cleanFirstLine -eq $OfficeC2RHeaders) {
        return 'OfficeC2R'
    }

    # 15. Fallback - PlainText with line numbers
    return 'PlainText'
}
