# Parser-W3C.ps1
# Parser for W3C Extended Log File Format
# Handles: pfirewall.log (Windows Firewall traffic logs)
# Part of Get-WindowsTroubleshootingReportCommunity v3.0
#
# Format: Self-describing with #Fields: header line defining column order
# Data lines are space-delimited, missing values represented by -

function Test-W3CFormat {
    param([string[]]$Lines)
    foreach($line in $Lines) {
        if($line -match '^#Version:' -or $line -match '^#Fields:') { return $true }
    }
    return $false
}

function Get-W3CTimeRange {
    param(
        [Parameter(Mandatory=$true)] [AllowEmptyString()] [string[]]$LogFileLines
    )

    $oldest = $null
    $newest = $null
    $dateFormat = 'yyyy-MM-dd'
    $timeFormat = 'HH:mm:ss'

    # Find first data line (non-comment)
    foreach($line in $LogFileLines) {
        if($line.StartsWith('#')) { continue }
        if($line.Trim().Length -eq 0) { continue }

        if($line -match '^(\d{4}-\d{2}-\d{2})\s(\d{2}:\d{2}:\d{2})') {
            try {
                $oldest = [datetime]::ParseExact("$($Matches[1]) $($Matches[2])", 'yyyy-MM-dd HH:mm:ss', $null)
                break
            } catch { continue }
        }
    }

    # Find last data line
    for($i = $LogFileLines.Count - 1; $i -ge 0; $i--) {
        $line = $LogFileLines[$i]
        if($line.StartsWith('#')) { continue }
        if($line.Trim().Length -eq 0) { continue }

        if($line -match '^(\d{4}-\d{2}-\d{2})\s(\d{2}:\d{2}:\d{2})') {
            try {
                $newest = [datetime]::ParseExact("$($Matches[1]) $($Matches[2])", 'yyyy-MM-dd HH:mm:ss', $null)
                break
            } catch { continue }
        }
    }

    return @{ Oldest = $oldest; Newest = $newest }
}

function Read-W3CLogEntries {
    <#
    .SYNOPSIS
        Parses W3C Extended Log File Format logs
    .DESCRIPTION
        Dynamically reads the #Fields: header to determine column order.
        Maps DROP action to Red color.
    #>
    param(
        [Parameter(Mandatory=$true)] [AllowEmptyString()] [string[]]$LogFileLines,
        [Parameter(Mandatory=$true)] $StartTimeObject,
        [Parameter(Mandatory=$true)] $EndTimeObject,
        [Parameter(Mandatory=$true)] [string]$LogFileName,
        [Parameter(Mandatory=$false)] [array]$KnownLogEventRuleObjects = @(),
        [Parameter(Mandatory=$false)] [bool]$AllEvents = $false
    )

    $entries = @()
    $lineNumber = 0
    $fields = @()

    foreach($line in $LogFileLines) {
        $lineNumber++

        # Parse #Fields: header
        if($line -match '^#Fields:\s+(.+)$') {
            $fields = $Matches[1] -split '\s+'
            continue
        }

        # Skip other comment lines
        if($line.StartsWith('#')) { continue }
        if($line.Trim().Length -eq 0) { continue }

        # Parse data line
        $values = $line -split '\s+'
        if($values.Count -lt 3) { continue }

        # Build a field-value mapping
        $fieldMap = @{}
        for($i = 0; $i -lt [Math]::Min($fields.Count, $values.Count); $i++) {
            $fieldMap[$fields[$i]] = $values[$i]
        }

        # Extract date and time
        $dateStr = $fieldMap['date']
        $timeStr = $fieldMap['time']
        if(-not $dateStr -or -not $timeStr) { continue }

        try {
            $dateObj = [datetime]::ParseExact("$dateStr $timeStr", 'yyyy-MM-dd HH:mm:ss', $null)
        } catch { continue }

        if($dateObj -lt $StartTimeObject -or $dateObj -gt $EndTimeObject) { continue }

        # Build message from all fields
        $action = if($fieldMap['action']) { $fieldMap['action'] } else { '-' }
        $protocol = if($fieldMap['protocol']) { $fieldMap['protocol'] } else { '-' }
        $srcIp = if($fieldMap['src-ip']) { $fieldMap['src-ip'] } else { '-' }
        $dstIp = if($fieldMap['dst-ip']) { $fieldMap['dst-ip'] } else { '-' }
        $srcPort = if($fieldMap['src-port']) { $fieldMap['src-port'] } else { '-' }
        $dstPort = if($fieldMap['dst-port']) { $fieldMap['dst-port'] } else { '-' }
        $path = if($fieldMap['path']) { $fieldMap['path'] } else { '-' }

        $message = "$action $protocol $srcIp`:$srcPort -> $dstIp`:$dstPort ($path)"

        # Color based on action
        $color = $null
        $levelDisplay = 'Information'
        switch($action) {
            'DROP' { $color = 'Red'; $levelDisplay = 'Warning' }
            'ALLOW' { $levelDisplay = 'Information' }
        }

        $Year = $dateObj.Year.ToString(); $Month = $dateObj.Month.ToString(); $Day = $dateObj.Day.ToString()
        $Hour = $dateObj.Hour.ToString(); $Minute = $dateObj.Minute.ToString(); $Second = $dateObj.Second.ToString()
        $dateTimeline = Format-DateTimeForTimeline -Year $Year -Month $Month -Day $Day -Hour $Hour -Minute $Minute -Second $Second

        $entry = @{
            DateTimeObject = $dateObj
            Date = $dateTimeline
            LogName = $LogFileName
            ProviderName = 'WindowsFirewall'
            Id = ''
            LevelDisplayName = $levelDisplay
            Message = $message
            Color = $color
            EventNumber = $lineNumber
            MessageToolTip = $null
            KnownCategoryName = $null
        }

        $ruleMatch = Match-EventRulesForLogEntry -LogMessage $message -KnownLogEventRuleObjects $KnownLogEventRuleObjects
        if($ruleMatch) {
            $entry.Color = $ruleMatch.Color
            $entry.MessageToolTip = $ruleMatch.MessageToolTip
            $entry.KnownCategoryName = $ruleMatch.CategoryName
            $entries += $entry
        } elseif($AllEvents -or $color -eq 'Red') {
            $entries += $entry
        }
    }

    return $entries
}
