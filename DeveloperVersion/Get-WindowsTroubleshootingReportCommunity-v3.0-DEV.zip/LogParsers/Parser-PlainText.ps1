# Parser-PlainText.ps1
# Fallback parser for unstructured/plain text log files
# Handles: Any text file that doesn't match a known structured format
# Part of Get-WindowsTroubleshootingReportCommunity v3.0
#
# Strategy: Best-effort timestamp extraction using multiple common patterns.
# If no timestamp found on a line, it gets the timestamp of the previous line.
# This is the fallback parser — it always accepts files.

# Common timestamp patterns to try in order
$Script:PlainTextTimestampPatterns = @(
    # ISO 8601: 2024-01-15T14:30:00 or 2024-01-15 14:30:00
    @{ Regex = '(\d{4})-(\d{2})-(\d{2})[T\s](\d{2}):(\d{2}):(\d{2})'; Groups = @(1,2,3,4,5,6); Order = 'YMD' },
    # US date: 01/15/2024 14:30:00 or 1/15/2024 2:30:00 PM
    @{ Regex = '(\d{1,2})/(\d{1,2})/(\d{4})\s+(\d{1,2}):(\d{2}):(\d{2})\s*(AM|PM)?'; Groups = @(1,2,3,4,5,6); Order = 'MDY'; AMPMGroup = 7 },
    # European date: 15.01.2024 14:30:00
    @{ Regex = '(\d{1,2})\.(\d{1,2})\.(\d{4})\s+(\d{1,2})[.:](\d{2})[.:](\d{2})'; Groups = @(1,2,3,4,5,6); Order = 'DMY' },
    # Date with slashes YMD: 2024/01/15 14:30:00
    @{ Regex = '(\d{4})/(\d{2})/(\d{2})\s+(\d{2}):(\d{2}):(\d{2})'; Groups = @(1,2,3,4,5,6); Order = 'YMD' },
    # Time only HH:MM:SS (no date — uses last known date)
    @{ Regex = '\b(\d{2}):(\d{2}):(\d{2})\b'; Groups = @(1,2,3); Order = 'TimeOnly' }
)

function Test-PlainTextFormat {
    # PlainText is the fallback — always returns true
    param([string[]]$Lines)
    return $true
}

function Get-PlainTextTimeRange {
    param(
        [Parameter(Mandatory=$true)] [AllowEmptyString()] [string[]]$LogFileLines
    )

    $oldest = $null
    $newest = $null

    # Try to find timestamps using our patterns
    foreach($line in $LogFileLines) {
        $dt = _ExtractPlainTextTimestamp -Line $line
        if($dt) {
            $oldest = $dt
            break
        }
    }

    for($i = $LogFileLines.Count - 1; $i -ge 0; $i--) {
        $dt = _ExtractPlainTextTimestamp -Line $LogFileLines[$i]
        if($dt) {
            $newest = $dt
            break
        }
    }

    return @{ Oldest = $oldest; Newest = $newest }
}

function _ExtractPlainTextTimestamp {
    param([string]$Line)

    foreach($pattern in $Script:PlainTextTimestampPatterns) {
        if($Line -match $pattern.Regex) {
            try {
                switch($pattern.Order) {
                    'YMD' {
                        $g = $pattern.Groups
                        return Get-Date -Year $Matches[$g[0]] -Month $Matches[$g[1]] -Day $Matches[$g[2]] -Hour $Matches[$g[3]] -Minute $Matches[$g[4]] -Second $Matches[$g[5]] -ErrorAction Stop
                    }
                    'MDY' {
                        $g = $pattern.Groups
                        $Hour = [int]$Matches[$g[3]]
                        if($pattern.AMPMGroup -and $Matches[$pattern.AMPMGroup]) {
                            $Hour = Convert-12HourTo24Hour -Hour $Hour -AMPM $Matches[$pattern.AMPMGroup]
                        }
                        return Get-Date -Month $Matches[$g[0]] -Day $Matches[$g[1]] -Year $Matches[$g[2]] -Hour $Hour -Minute $Matches[$g[4]] -Second $Matches[$g[5]] -ErrorAction Stop
                    }
                    'DMY' {
                        $g = $pattern.Groups
                        return Get-Date -Day $Matches[$g[0]] -Month $Matches[$g[1]] -Year $Matches[$g[2]] -Hour $Matches[$g[3]] -Minute $Matches[$g[4]] -Second $Matches[$g[5]] -ErrorAction Stop
                    }
                    'TimeOnly' {
                        # Return today's date with the parsed time
                        $g = $pattern.Groups
                        return Get-Date -Hour $Matches[$g[0]] -Minute $Matches[$g[1]] -Second $Matches[$g[2]] -ErrorAction Stop
                    }
                }
            } catch { continue }
        }
    }
    return $null
}

function Read-PlainTextLogEntries {
    <#
    .SYNOPSIS
        Fallback parser for unstructured text log files
    .DESCRIPTION
        Best-effort timestamp extraction from each line.
        Lines without timestamps inherit the last known timestamp.
        EventRules matching still applies for color/category classification.
    #>
    param(
        [Parameter(Mandatory=$true)] [AllowEmptyString()] [string[]]$LogFileLines,
        [Parameter(Mandatory=$true)] $StartTimeObject,
        [Parameter(Mandatory=$true)] $EndTimeObject,
        [Parameter(Mandatory=$true)] [string]$LogFileName,
        [Parameter(Mandatory=$false)] [array]$KnownLogEventRuleObjects = @(),
        [Parameter(Mandatory=$false)] [bool]$AllEvents = $false
    )

    $entries = @()
    $lineNumber = 0
    $lastKnownDate = $null

    foreach($line in $LogFileLines) {
        $lineNumber++
        $line = $line -replace "^\uFEFF", ""

        if([string]::IsNullOrWhiteSpace($line)) { continue }

        $dateObj = _ExtractPlainTextTimestamp -Line $line
        if($dateObj) {
            $lastKnownDate = $dateObj
        } else {
            $dateObj = $lastKnownDate
        }

        if(-not $dateObj) { continue }
        if($dateObj -lt $StartTimeObject -or $dateObj -gt $EndTimeObject) { continue }

        $message = $line
        $color = $null
        $levelDisplay = 'Information'

        # Basic keyword-based classification
        if($message -match '\b(ERROR|FATAL|CRITICAL|FAIL(ED)?)\b') {
            $color = 'Red'
            $levelDisplay = 'Error'
        } elseif($message -match '\b(WARN(ING)?)\b') {
            $color = 'Yellow'
            $levelDisplay = 'Warning'
        }

        $Year = $dateObj.Year.ToString(); $Month = $dateObj.Month.ToString(); $Day = $dateObj.Day.ToString()
        $HourStr = $dateObj.Hour.ToString(); $MinuteStr = $dateObj.Minute.ToString(); $SecondStr = $dateObj.Second.ToString()
        $dateTimeline = Format-DateTimeForTimeline -Year $Year -Month $Month -Day $Day -Hour $HourStr -Minute $MinuteStr -Second $SecondStr

        $entry = @{
            DateTimeObject = $dateObj
            Date = $dateTimeline
            LogName = $LogFileName
            ProviderName = 'PlainText'
            Id = ''
            LevelDisplayName = $levelDisplay
            Message = $message
            Color = $color
            EventNumber = $lineNumber
            MessageToolTip = $null
            KnownCategoryName = $null
        }

        $ruleMatch = Match-EventRulesForLogEntry -LogMessage $message -KnownLogEventRuleObjects $KnownLogEventRuleObjects
        if($ruleMatch) {
            $entry.Color = $ruleMatch.Color
            $entry.MessageToolTip = $ruleMatch.MessageToolTip
            $entry.KnownCategoryName = $ruleMatch.CategoryName
            $entries += $entry
        } elseif($AllEvents -or $color) {
            $entries += $entry
        }
    }

    return $entries
}
