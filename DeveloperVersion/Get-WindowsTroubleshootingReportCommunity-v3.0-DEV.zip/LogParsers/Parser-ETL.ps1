# Parser-ETL.ps1
# Parser for Event Trace Log (ETL) binary files
# Handles: *.etl files using dual-strategy conversion
# Part of Get-WindowsTroubleshootingReportCommunity v3.0
#
# Strategy:
# 1. Try Get-WinEvent -Path <file.etl> -Oldest (requires matching manifest on system)
# 2. Fallback: tracerpt.exe <file.etl> -o output.xml -of XML -y, then parse the XML
# 3. If both fail: skip the file with a warning

function Test-ETLFormat {
    param(
        [Parameter(Mandatory=$true)] [string]$FilePath
    )
    return ($FilePath -match '\.etl$')
}

function Get-ETLTimeRange {
    param(
        [Parameter(Mandatory=$true)] [string]$FilePath
    )

    $oldest = $null
    $newest = $null

    # Try Get-WinEvent first
    try {
        $firstEvent = Get-WinEvent -Path $FilePath -Oldest -MaxEvents 1 -ErrorAction Stop
        $oldest = $firstEvent.TimeCreated

        $lastEvent = Get-WinEvent -Path $FilePath -MaxEvents 1 -ErrorAction Stop
        $newest = $lastEvent.TimeCreated

        return @{ Oldest = $oldest; Newest = $newest }
    } catch {
        # Get-WinEvent failed — try tracerpt
    }

    # Tracerpt fallback: just return null — full parse will handle it
    return @{ Oldest = $null; Newest = $null }
}

# Script-scoped flag: set to $true by _Read-ETLViaTracerpt when tracerpt.exe runs and
# produces output.xml — used to suppress false 'could not be parsed' warnings when
# tracerpt succeeded but returned 0 events in the selected time window (PowerShell
# empty-array null-collapse makes an empty result look the same as a failure)
$Script:_ETLTracerptRanSuccessfully = $false

function Read-ETLLogEntries {
    <#
    .SYNOPSIS
        Parses ETL binary trace files
    .DESCRIPTION
        Uses tracerpt.exe first (reads both Windows manifest registry AND ETL-embedded manifests),
        with Get-WinEvent as a fallback when tracerpt fails to run.
        Returns structured timeline entries compatible with the report.
    #>
    param(
        [Parameter(Mandatory=$true)] [string]$FilePath,
        [Parameter(Mandatory=$true)] $StartTimeObject,
        [Parameter(Mandatory=$true)] $EndTimeObject,
        [Parameter(Mandatory=$true)] [string]$LogFileName,
        [Parameter(Mandatory=$false)] [array]$KnownLogEventRuleObjects = @(),
        [Parameter(Mandatory=$false)] [bool]$AllEvents = $false
    )

    # Strategy 1: tracerpt.exe → XML
    # tracerpt reads both the Windows manifest registry AND manifests embedded in the ETL file,
    # so it is strictly better than Get-WinEvent which only uses the registry.
    $Script:_ETLTracerptRanSuccessfully = $false
    $entries = _Read-ETLViaTracerpt -FilePath $FilePath -StartTimeObject $StartTimeObject -EndTimeObject $EndTimeObject -LogFileName $LogFileName -KnownLogEventRuleObjects $KnownLogEventRuleObjects -AllEvents $AllEvents

    if($entries -ne $null) {
        return $entries
    }

    # tracerpt ran successfully but returned 0 events (all outside the time window).
    # PowerShell collapses empty arrays to $null across function boundaries — the flag
    # distinguishes this from a genuine tracerpt failure.
    if($Script:_ETLTracerptRanSuccessfully) {
        return @()
    }

    # Strategy 2: Get-WinEvent fallback (when tracerpt itself fails to run, e.g. not on PATH)
    $entries = _Read-ETLViaGetWinEvent -FilePath $FilePath -StartTimeObject $StartTimeObject -EndTimeObject $EndTimeObject -LogFileName $LogFileName -KnownLogEventRuleObjects $KnownLogEventRuleObjects -AllEvents $AllEvents

    if($entries -ne $null) {
        return $entries
    }

    Write-Warning "ETL file could not be parsed by tracerpt.exe or Get-WinEvent: $FilePath"
    return @()
}

function _Read-ETLViaGetWinEvent {
    param(
        [string]$FilePath,
        $StartTimeObject,
        $EndTimeObject,
        [string]$LogFileName,
        [array]$KnownLogEventRuleObjects,
        [bool]$AllEvents
    )

    try {
        $events = Get-WinEvent -Path $FilePath -Oldest -ErrorAction Stop
    } catch {
        return $null  # Signal to try fallback
    }

    $entries = @()
    $eventNumber = 0

    foreach($evt in $events) {
        $eventNumber++

        $dateObj = $evt.TimeCreated
        if(-not $dateObj) { continue }
        if($dateObj -lt $StartTimeObject -or $dateObj -gt $EndTimeObject) { continue }

        $provider = $evt.ProviderName
        $eventId = $evt.Id.ToString()
        $message = $evt.Message
        if(-not $message) { $message = $evt.FormatDescription() }
        if(-not $message) {
            # Provider manifest is not registered on this machine — show GUID as a clue if name is empty
            $providerHint = if($provider) { $provider } elseif($evt.ProviderId -and $evt.ProviderId -ne [guid]::Empty) { "GUID:$($evt.ProviderId)" } else { 'unknown provider' }
            $message = "EventID: $eventId (no message — manifest not available for $providerHint)"
        }

        $color = $null
        $levelDisplay = 'Information'

        switch($evt.Level) {
            1 { $color = 'Red'; $levelDisplay = 'Critical' }
            2 { $color = 'Red'; $levelDisplay = 'Error' }
            3 { $color = 'Yellow'; $levelDisplay = 'Warning' }
            4 { $levelDisplay = 'Information' }
            5 { $levelDisplay = 'Verbose' }
        }

        $Year = $dateObj.Year.ToString(); $Month = $dateObj.Month.ToString(); $Day = $dateObj.Day.ToString()
        $HourStr = $dateObj.Hour.ToString(); $MinuteStr = $dateObj.Minute.ToString(); $SecondStr = $dateObj.Second.ToString()
        $dateTimeline = Format-DateTimeForTimeline -Year $Year -Month $Month -Day $Day -Hour $HourStr -Minute $MinuteStr -Second $SecondStr

        $entry = @{
            DateTimeObject = $dateObj
            Date = $dateTimeline
            LogName = $LogFileName
            ProviderName = $provider
            Id = $eventId
            LevelDisplayName = $levelDisplay
            Message = $message
            Color = $color
            EventNumber = $eventNumber
            MessageToolTip = $null
            KnownCategoryName = $null
        }

        $ruleMatch = Match-EventRulesForLogEntry -LogMessage $message -KnownLogEventRuleObjects $KnownLogEventRuleObjects
        if($ruleMatch) {
            $entry.Color = $ruleMatch.Color
            $entry.MessageToolTip = $ruleMatch.MessageToolTip
            $entry.KnownCategoryName = $ruleMatch.CategoryName
            $entries += $entry
        } elseif($AllEvents -or $color) {
            $entries += $entry
        }
    }

    return $entries
}

function _Read-ETLViaTracerpt {
    param(
        [string]$FilePath,
        $StartTimeObject,
        $EndTimeObject,
        [string]$LogFileName,
        [array]$KnownLogEventRuleObjects,
        [bool]$AllEvents
    )

    # Check tracerpt.exe is available
    $tracerpt = Get-Command 'tracerpt.exe' -ErrorAction SilentlyContinue
    if(-not $tracerpt) {
        Write-Warning "tracerpt.exe not found in PATH"
        return $null
    }

    # Create temp directory for output
    $tempDir = Join-Path $env:TEMP "ETLParser_$(Get-Random)"
    try {
        New-Item -ItemType Directory -Path $tempDir -Force -ErrorAction Stop | Out-Null
    } catch {
        Write-Warning "Failed to create temp directory for ETL parsing: $_"
        return $null
    }

    $xmlOutput = Join-Path $tempDir 'output.xml'

    try {
        # Run tracerpt.exe — use -y to skip overwrite prompt, -lr for less-restricted schema parsing
        # Redirect stdout/stderr to temp files so tracerpt's progress output does not pollute the console
        $stdoutFile = Join-Path $tempDir 'tracerpt_stdout.txt'
        $stderrFile  = Join-Path $tempDir 'tracerpt_stderr.txt'
        $process = Start-Process -FilePath 'tracerpt.exe' -ArgumentList "`"$FilePath`" -o `"$xmlOutput`" -of XML -y -lr" -Wait -NoNewWindow -PassThru -RedirectStandardOutput $stdoutFile -RedirectStandardError $stderrFile -ErrorAction Stop

        if(-not (Test-Path $xmlOutput)) {
            Write-Warning "tracerpt.exe failed with exit code $($process.ExitCode) for: $FilePath"
            return $null
        }
        # Non-zero exit but output.xml was created — schema warnings are non-fatal, try to parse
        if($process.ExitCode -ne 0) {
            Write-Verbose "tracerpt.exe exited with code $($process.ExitCode) (schema warnings) for: $FilePath — attempting XML parse anyway"
        }

        # tracerpt created output.xml — signal success even if 0 events match the time window
        $Script:_ETLTracerptRanSuccessfully = $true

        # Parse the resulting XML using our XML parser
        $xmlEntries = Read-XMLLogEntries -FilePath $xmlOutput -StartTimeObject $StartTimeObject -EndTimeObject $EndTimeObject -LogFileName $LogFileName -KnownLogEventRuleObjects $KnownLogEventRuleObjects -AllEvents $AllEvents
        return $xmlEntries
    }
    catch {
        Write-Warning "tracerpt.exe conversion failed for ETL file: $FilePath - $_"
        return $null
    }
    finally {
        # Clean up temp directory
        if(Test-Path $tempDir) {
            Remove-Item -Path $tempDir -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
}
