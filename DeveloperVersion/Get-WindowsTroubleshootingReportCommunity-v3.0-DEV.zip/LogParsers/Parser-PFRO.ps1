# Parser-PFRO.ps1
# Parser for Pending File Rename Operations log
# Handles: PFRO.log (Windows Setup pending file operations)
# Part of Get-WindowsTroubleshootingReportCommunity v3.0
#
# Format: YYYY/MM/DD HH:MM:SS.mmm Message

$Script:PFROLineRegex = '^(\d{4})/(\d{2})/(\d{2})\s+(\d{2}):(\d{2}):(\d{2})\.(\d{3})\s+(.+)$'

function Test-PFROFormat {
    param([string[]]$Lines)
    $matchCount = 0
    $testLines = if($Lines.Count -gt 20) { $Lines[0..19] } else { $Lines }
    foreach($line in $testLines) {
        if($line -match $Script:PFROLineRegex) {
            $matchCount++
            if($matchCount -ge 2) { return $true }
        }
    }
    return $false
}

function Get-PFROTimeRange {
    param(
        [Parameter(Mandatory=$true)] [AllowEmptyString()] [string[]]$LogFileLines
    )

    $oldest = $null
    $newest = $null

    foreach($line in $LogFileLines) {
        if($line -match $Script:PFROLineRegex) {
            try {
                $oldest = Get-Date -Year $Matches[1] -Month $Matches[2] -Day $Matches[3] -Hour $Matches[4] -Minute $Matches[5] -Second $Matches[6] -Millisecond $Matches[7] -ErrorAction Stop
                break
            } catch { continue }
        }
    }

    for($i = $LogFileLines.Count - 1; $i -ge 0; $i--) {
        if($LogFileLines[$i] -match $Script:PFROLineRegex) {
            try {
                $newest = Get-Date -Year $Matches[1] -Month $Matches[2] -Day $Matches[3] -Hour $Matches[4] -Minute $Matches[5] -Second $Matches[6] -Millisecond $Matches[7] -ErrorAction Stop
                break
            } catch { continue }
        }
    }

    return @{ Oldest = $oldest; Newest = $newest }
}

function Read-PFROLogEntries {
    <#
    .SYNOPSIS
        Parses PFRO.log pending file rename operation logs
    .DESCRIPTION
        Extracts timestamps and file operation messages.
        Flags error keywords (FAIL, Error) as Red.
    #>
    param(
        [Parameter(Mandatory=$true)] [AllowEmptyString()] [string[]]$LogFileLines,
        [Parameter(Mandatory=$true)] $StartTimeObject,
        [Parameter(Mandatory=$true)] $EndTimeObject,
        [Parameter(Mandatory=$true)] [string]$LogFileName,
        [Parameter(Mandatory=$false)] [array]$KnownLogEventRuleObjects = @(),
        [Parameter(Mandatory=$false)] [bool]$AllEvents = $false
    )

    $entries = @()
    $lineNumber = 0

    foreach($line in $LogFileLines) {
        $lineNumber++
        $line = $line -replace "^\uFEFF", ""

        if($line -notmatch $Script:PFROLineRegex) { continue }

        $Year = $Matches[1]; $Month = $Matches[2]; $Day = $Matches[3]
        $Hour = $Matches[4]; $Minute = $Matches[5]; $Second = $Matches[6]; $Millisecond = $Matches[7]
        $message = $Matches[8]

        try {
            $dateObj = Get-Date -Year $Year -Month $Month -Day $Day -Hour $Hour -Minute $Minute -Second $Second -Millisecond $Millisecond -ErrorAction Stop
        } catch { continue }

        if($dateObj -lt $StartTimeObject -or $dateObj -gt $EndTimeObject) { continue }

        $color = $null
        $levelDisplay = 'Information'

        if($message -match '\b(FAIL|Error)\b' -or $message -match '0x[89A-Fa-f]') {
            $color = 'Red'
            $levelDisplay = 'Error'
        } elseif($message -match '\bWarning\b') {
            $color = 'Yellow'
            $levelDisplay = 'Warning'
        }

        $dateTimeline = Format-DateTimeForTimeline -Year $Year -Month $Month -Day $Day -Hour $Hour -Minute $Minute -Second $Second

        $entry = @{
            DateTimeObject = $dateObj
            Date = $dateTimeline
            LogName = $LogFileName
            ProviderName = 'PFRO'
            Id = ''
            LevelDisplayName = $levelDisplay
            Message = $message
            Color = $color
            EventNumber = $lineNumber
            MessageToolTip = $null
            KnownCategoryName = $null
        }

        $ruleMatch = Match-EventRulesForLogEntry -LogMessage $message -KnownLogEventRuleObjects $KnownLogEventRuleObjects
        if($ruleMatch) {
            $entry.Color = $ruleMatch.Color
            $entry.MessageToolTip = $ruleMatch.MessageToolTip
            $entry.KnownCategoryName = $ruleMatch.CategoryName
            $entries += $entry
        } elseif($AllEvents -or $color) {
            $entries += $entry
        }
    }

    return $entries
}
